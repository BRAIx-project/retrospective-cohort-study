#' Get reader summary statistics
#'
#' @param reader_df A data frame. The reader data frame.
#' @param weighted TRUE / FALSE. Whether to weight the readers' performance by their number of reads.
#' @param ... Additional arguments to pass to `mean_reader_by_position`.
#'
#' @export
get_reader_summary <- function(reader_df, weighted = TRUE, ...) {
  check_reader_df_has_correct_unit(reader_df)
  check_dates(reader_df)

  message("- Computing the weighted mean of the (first two) readers performance (TPR, FPR)")
  mean_reader_perf <- mean_reader(reader_df, weighted, ...)

  message("- Computing the weighted mean readers performance by positions")
  mean_reader_perf_by_position <- mean_reader_by_position(reader_df, ...)

  message("Complete")
  list(
    mean_reader = mean_reader_perf,
    mean_reader_by_position = mean_reader_perf_by_position,
    is_weighted = weighted
  )
}


#' Check reader file has the correct unit, i.e. one episode per row
#' @param reader_df A data frame. The reader data frame.
check_reader_df_has_correct_unit <- function(reader_df) {
  num_ep <- reader_df |>
    filter(reader_number == 1) |>
    nrow()
  message(
    "- Checking reader file has the correct unit (episodes): ",
    num_ep == count(reader_df$episode_id)
  )
  stopifnot(num_ep == count(reader_df$episode_id))
}


#' Check the development set dates are correct
#' @param reader_df A data frame. The reader data frame.
check_dates <- function(reader_df) {
  date_1 <- reader_df$screening_date |> sort() |> head(1)
  date_2 <- reader_df$screening_date |> sort() |> tail(1)
  message(
    "- Checking the development set dates are correct: ",
    "from ", date_1, " to ", date_2
  )
}


#' Compute the average TPR and FPR of the readers
#'
#' @param reader_df A data frame. The reader data frame.
#' @param weighted TRUE / FALSE. Whether to weight the mean by the number of reads.
#' @param ... Additional arguments to pass to `get_reader_performance`.
#'
#' @export
mean_reader <- function(reader_df, weighted = TRUE, ...) {
  reader_individual_perf <- reader_df |>
    filter(reader_number %in% c(1, 2)) |>
    get_reader_performance(...)

  weighted_individual_perf <- reader_individual_perf |>
    mutate(weight = n_reads / sum(n_reads)) |>
    select(reader_id, weight, TPR, FPR)

  if (weighted) {
    weight <- weighted_individual_perf$weight
  } else {
    weight <- 1 / nrow(weighted_individual_perf)
  }

  tpr <- weighted_individual_perf$TPR
  fpr <- weighted_individual_perf$FPR
  list(
    weighted_tpr = sum(weight * tpr),
    weighted_fpr = sum(weight * fpr),
    weight = weight,
    tpr = tpr,
    fpr = fpr
  )
}


#' Compute the average TPR and FPR of the readers by position
#'
#' @param reader_df A data frame. The reader data frame.
#' @param ... Additional arguments to pass to `get_reader_performance`.
#'
#' @export
mean_reader_by_position <- function(reader_df, ...) {
  rbind_lapply(1:3, function(i) {
    reader_df |>
      filter(reader_number == i) |>
      get_reader_performance(...) |>
      mutate(weights = n_reads / sum(n_reads)) |>
      summarise(
        weighted_tpr = sum(weights * TPR),
        weighted_fpr = sum(weights * FPR),
        tpr = mean(TPR),
        fpr = mean(FPR)
      )
  })
}


#' Get the individual performance of the readers
#'
#' @param reader_df A data frame; the data frame containing the readers' read.
#' @param min_read A number; the minimum number of reads required of the reader
#' to be included.
#'
#' @export
get_reader_performance <- function(reader_df, min_read = -1) {
  readers_grouped_by_id <- reader_df |>
    group_by(reader_id) |>
    nest() |>
    mutate(n_reads = sapply(data, nrow)) |>
    filter(n_reads >= min_read)

  confusion_table <- readers_grouped_by_id$data |>
    lapply(function(df0) {
      df0 |>
        rename(episode_prediction = individual_recall) |>
        confusion_matrix()
    }) # Note 1
  # Note 1: Human readers only make prediction 0 or 1, so we can use any
  # threshold in-between.

  confusion_df <- confusion_table |>
    lapply(as.data.frame) %>%
    do.call(rbind, .)

  cbind(readers_grouped_by_id, confusion_df) |>
    select(-data) |>
    ungroup()
}


#' Get the consensus performance of the readers
#'
#' @param reader_df A data frame; the data frame containing the readers' read.
#'
#' @export
get_consensus_performance <- function(reader_df) {
  reader_df |>
    rename(episode_prediction = consensus_recall) |>
    confusion_matrix() |>
    as.data.frame()
}
