#' Run simulation analysis
#' @description
#' Performs the simulation of the AI replacement scenarios with the second reader
#' arbiter and mixed third reader arbiter respectively.
#'
#' @param accession_df A data frame; the placeholder for storing the simulation result.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_df A data frame; the model predictions.
#' @param replacement_threshold The (manufacturer specific) threshold for the replacement scenario.
#' @param bandpass_threshold The (manufacturer specific) threshold for the band-pass scenario.
#' @param seed An integer; the random seed.
#' @param skip_bandpass TRUE / FALSE; whether to skip the bandpass simulation.
#' This is useful during bootstrap. As the bandpass simulation is not stochastic,
#' rerunning the simulation would only generate duplicate results. Hence, this
#' should be set to `TRUE` for bootstrap.
#' @param ... Includes `parallel` (logical, default to be FALSE), `mc.cores`
#'   (integer, default to be 2), and other optional parameters to be passed to
#'   `parallel::mclapply`.
#'
#' @return A list of simulation results
#' @export
run_simulation_arbiter_variations <- function(accession_df, reader_df, model_df,
                           replacement_threshold, bandpass_threshold,
                           seed = 1234, skip_bandpass = FALSE, ...) {
  set_lapply <- function(parallel = FALSE, mc.cores = 2, ...) {
    if (!parallel) return(lapply)
    parallel_lapply <- function(...) parallel::mclapply(mc.cores = mc.cores, ...)
    parallel_lapply
  }
  lapply2 <- set_lapply(...)

  # Baseline scenario
  baseline_result <- run_baseline(accession_df, reader_df)

  # AI replacement scenario (second reader arbiter)
  AI_replacement_result_second_reader_arbiter <- run_AI_replacement_second_reader_arbiter(
    accession_df, reader_df, model_df, replacement_threshold, seed, baseline_result)

   # AI replacement scenario (mixed reader)
  AI_replacement_result_mixed_third_arbiter <- run_AI_replacement_mixed_third_reader(
    accession_df, reader_df, model_df, replacement_threshold, seed, baseline_result)

  list(
    AI_replacement_second_reader_arbiter_result = AI_replacement_result_second_reader_arbiter,
    AI_replacement_mixed_third_arbiter_result = AI_replacement_result_mixed_third_arbiter
  )
}



run_AI_replacement_second_reader_arbiter <- function(accession_df, reader_df, model_df, threshold, seed, baseline_result, ...) {
  model_thresholded_df <- apply_manufacturer_threshold(model_df, threshold)
  set.seed(seed)
  message("Replacing reader randomly")
  analysis_api(AI_independent_replace_random_second_reader_arbiter,
               AI_independent_random_second_reader_arbiter_economics,
               independent_flowchart,
               independent_flowchart_data,
               c("Reader 1", "AI Reader", "Reader 3"),
               "AI reader replacement",
               baseline_econ = baseline_result$econ,
               # actual arguments
               accession_df = accession_df,
               reader_df = reader_df,
               model_pred = model_thresholded_df,
               threshold = 0.5, ...)
}

run_AI_replacement_mixed_third_reader<- function(accession_df, reader_df, model_df, threshold, seed, baseline_result, ...) {
  model_thresholded_df <- apply_manufacturer_threshold(model_df, threshold)
  set.seed(seed)
  message("Replacing reader randomly")
  analysis_api(AI_independent_replace_random_mixed_sim,
               AI_independent_random_mixed_sim_economics,
               independent_flowchart,
               independent_flowchart_data,
               c("Reader 1", "AI Reader", "Reader 3"),
               "AI reader replacement",
               baseline_econ = baseline_result$econ,
               # actual arguments
               accession_df = accession_df,
               reader_df = reader_df,
               model_pred = model_thresholded_df,
               threshold = 0.5, ...)
}
