#' Find the threshold that matches a specific value of metrics
#'
#' @param model_df A data frame; the model data frame.
#' @param target "sensitivities" or "specificities".
#' @param target_value A value between 0 and 1; the target value to match.
#'
#' @return An one-row data frame.
#' @export
find_threshold_matching <- function(model_df, target, target_value) {
  roc0 <- roc(model_df)
  match_metrics(roc0, target, target_value)
}

match_metrics <- function(roc0, target, target_value) {
  if (!inherits(roc0, "roc")) {
    return(data.frame(sensitivities = NA, specificities = NA,
                      youden = NA, thresholds = NA, is_better = NA))
  }

  roc_df <- data.frame(sensitivities = roc0$sensitivities,
                       specificities = roc0$specificities,
                       youden = roc0$sensitivities + roc0$specificities - 1,
                       thresholds = roc0$thresholds)
  roc_df$is_better <- roc_df[[target]] > target_value
  roc_df |>
    filter(is_better) |>
    arrange(desc(!!sym(target))) |>
    tail(1)
}


#' Find the manufacturer specific thresholds that match a specific value of metrics
#'
#' @param model_df A data frame; the model data frame. It must contain the
#' "manufacturer" column.
#' @param target "sensitivities" or "specificities".
#' @param target_value A value between 0 and 1; the target value to match.
#'
#' @return A data frame, where each row is the threshold of a manufacturer.
#'
#' @note We consider the same manufacturer using different algorithms as if they
#' are different manufacturers.
#'
#' @export
find_manufacturer_threshold_matching <- function(model_df, target, target_value) {
  stopifnot("manufacturer" %in% colnames(model_df))
  default_threshold <- find_threshold_matching(model_df, target, target_value)

  model_roc_by_algorithm <- model_df |>
    rename(algorithm = manufacturer) |>
    group_by(algorithm) |>
    nest() |>
    mutate(num_data = sapply(data, nrow),
           threshold = lapply(data, find_threshold_matching,
                              target = target,
                              target_value = target_value))

  threshold <- do.call(rbind, model_roc_by_algorithm$threshold)

  result <- model_roc_by_algorithm |>
    select(algorithm, num_data) |>
    cbind(threshold) |>
    rbind(data.frame(algorithm = "default",
                     num_data = NA,
                     default_threshold))
  result
}


#' Apply manufacturer specific threshold
#'
#' @param model_df A data frame; the model data frame. It must contain the
#' "manufacturer" column.
#' @param thresholds A dataframe of manufacturer specific thresholds,
#' the output from `find_manufacturer_threshold_matching`.
#'
#' @return A data frame containing the binarised episode predictions.
#' @export
apply_manufacturer_threshold <- function(model_df, thresholds) {
  model_pred_group_by_algor <- model_df |>
    rename(algorithm = manufacturer) |>
    group_by(algorithm) |>
    nest()

  thresholds_list <- thresholds$thresholds |>
    as.list() |>
    setNames(thresholds$algorithm)

  thresholded_episode_prediction <- Map(
    function(df0, algorithm) {
      threshold <- thresholds_list[[algorithm]]
      # For algorithm that does not exist in the developing test or exists
      # but have too few samples to match the ROC for matching, we use the
      # default threshold (computed using all data points)
      if (is.na(threshold) || is.null(threshold)) {
        threshold <- thresholds_list[["default"]]
      }
      data.frame(episode_id = df0$episode_id,
                 episode_prediction = 1.0 * (df0$episode_prediction > threshold))
    },
    model_pred_group_by_algor$data,
    model_pred_group_by_algor$algorithm)

  id_with_thresholded_prediction <- do.call(rbind, thresholded_episode_prediction)
  result_pred <- model_df
  result_pred$episode_prediction <- NULL
  left_join(result_pred,
            id_with_thresholded_prediction,
            by = "episode_id")
}
