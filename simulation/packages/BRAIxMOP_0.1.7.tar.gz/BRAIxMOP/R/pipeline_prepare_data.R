#' Prepare / process data for simulation
#'
#' @param model_file A character string; the path to the model file.
#' @param reader_file A character string; the path to the reader file.
#' @param is_test TRUE / FALSE; whether the input files are from the testing / developing set.
#' @param output_directory A character string; the path to the output directory.
#'
#' @export
prepare_data_for_simulation <- function(model_file, reader_file, is_test,
                                        output_directory) {
  dir_create(output_directory)

  message("=============================================")
  message("Setting up for model operating point analysis")
  message("=============================================")
  message(glue("Setting up using the {yellow(ifelse(is_test, 'testing', 'development'))} set."))
  data <- list(model_df = load_model_file(model_file),
               reader_df = load_reader_file(reader_file))

  message("---------------------------------------------")
  message("Performing data validation and cleaning")
  data <- match_episodes(data$model_df, data$reader_df, output_directory)

  data <- fix_abnormal_ambiguous_outcome(data$model_df, data$reader_df)

  data <- list(model_df = convert_model_df_into_unit_of_episodes(data$model_df),
               reader_df = convert_reader_df_into_unit_of_episodes(data$reader_df))

  save_clean_data_to_disk(data$model_df, data$reader_df, is_test, output_directory)
  message_heading("Setup is complete.")
  TRUE
}


#' Load the reader file
#' @param reader_file A character string; the path to the reader file.
#' @return A data frame.
#' @export
load_reader_file <- function(reader_file) {
  message_heading("Loading the reader file")
  reader_df <- read.csv(reader_file)

  message("Reporting the number of reads (episodes)")
  message("  Total number of reads: ", num_episodes(reader_df))
  message("  Number of reader 1 reads: ",
          reader_df |> filter(reader_number == 1) |> num_episodes())
  message("  Number of reader 2 reads: ",
          reader_df |> filter(reader_number == 2) |> num_episodes())
  message("  Number of reader 3 reads: ",
          reader_df |> filter(reader_number == 3) |> num_episodes())
  reader_df
}


#' Load the model file
#' @param model_file A character string; the path to the model file.
#' @return A data frame.
#' @export
load_model_file <- function(model_file) {
  message_heading("Loading the model file")
  model_df <- read.csv(model_file)

  message("Reporting the number of episodes")
  message("  Total number of episodes: ", num_episodes(model_df))
  message("  Number of episodes by outcome")
  message_table(table(model_df$episode_outcome))
  model_df
}


#' Find matching episodes between the model and the reader files
#' @param model_df A data frame. The model data frame.
#' @param reader_df A data frame. The reader data frame.
#' @param output_directory A string; the path to the output directory.
match_episodes <- function(model_df, reader_df, output_directory) {
  message_heading("Ensure only episodes that appear in both the image-view and the reader-view are inspected.")
  message("  Number of episodes in model predictions: ", num_episodes(model_df))
  message("  Number of episodes in reader records: ", num_episodes(reader_df))

  common_eid <- intersect(reader_df$episode_id, model_df$episode_id)
  message("  Number of common episodes: ", count(common_eid))

  # Keep track of excluded episodes
  excluded_eid <- c(setdiff(reader_df$episode_id, model_df$episode_id),
                    setdiff(model_df$episode_id, reader_df$episode_id))
  excluded_df <- NULL
  if (length(excluded_eid) > 0) {
    excluded_df <- data.frame(episode_id = unique(excluded_eid),
                              reasons = "unmatched_records_between_model_predictions_and_reader_reads")
    log_path <- file.path(output_directory, "excluded_episodes.csv")
    message(glue("Logging {length(excluded_eid)} excluded episodes to: {log_path}"))
    write.csv(excluded_df, file = log_path, row.names = F)
  }

  message("  Performing filtering")
  reader_matched <- reader_df |> filter(episode_id %in% common_eid)
  model_matched <- model_df |> filter(episode_id %in% common_eid)

  message("  Number of episodes in model predictions: ", num_episodes(model_matched))
  message("  Number of episodes in reader records: ", num_episodes(reader_matched))
  message("  Excluded episodes: ", count(excluded_eid))
  stopifnot(num_episodes(model_matched) == num_episodes(reader_matched))

  list(model_df = model_matched,
       reader_df = reader_matched,
       excluded_df = excluded_df)
}


#' Tidy up the abnormal / ambiguous outcome
#' @param model_df A data frame. The model data frame.
#' @param reader_df A data frame. The reader data frame.
fix_abnormal_ambiguous_outcome <- function(model_df, reader_df) {
  message_heading("Episodes with outcome '20' are considered '0' for modelling purposes.")
  message("Model file:")
  model_pred <- model_df
  message_table(table(model_pred$episode_outcome))

  model_pred$episode_outcome[model_pred$episode_outcome == 20] <- 0
  message_table(table(model_pred$episode_outcome))

  message("Reader file:")
  reader_perf <- reader_df
  message_table(table(reader_perf$episode_outcome))

  reader_perf$episode_outcome[reader_perf$episode_outcome == 20] <- 0
  message_table(table(reader_perf$episode_outcome))

  list(model_df = model_pred,
       reader_df = reader_perf)
}


#' Convert model predictions into unit of episodes
#' @param model_df A data frame. The model data frame.
convert_model_df_into_unit_of_episodes <- function(model_df) {
  message_heading("Converting the unit in the model file from image to episode")
  message("  Number of rows in model file: ", nrow(model_df))
  message("  Number of episodes in model file: ", num_episodes(model_df))
  message("  Performing conversion")
  model_pred <- model_df |> as_episode_df(by = "mean-max")
  message("  Number of rows in model file: ", nrow(model_pred))
  message("  Number of episodes in model file: ", num_episodes(model_pred))
  stopifnot(nrow(model_pred) == num_episodes(model_pred))
  model_pred
}

#' Convert reader reads into unit of episodes
#' @param reader_df A data frame. The reader data frame.
convert_reader_df_into_unit_of_episodes <- function(reader_df) {
  # Careful that the unit in the reader file is lesion assessment, not episode.
  message_heading("Converting the unit in the reader file from lesion to episode")
  message("  Number of rows in reader records: ", nrow(reader_df))
  message("  Number of records by reader 1: ", reader_df |> filter(reader_number == 1) |> nrow())
  message("  Number of records by reader 2: ", reader_df |> filter(reader_number == 2) |> nrow())
  message("  Number of episodes in reader records: ", num_episodes(reader_df))

  message("  Performing conversion")
  reader_df <- reader_df |>
    group_by(episode_id, reader_number) |>
    slice_sample(n = 1) |>
    ungroup()
  message("  Number of rows in reader records: ", nrow(reader_df))
  message("  Number of records by reader 1: ", reader_df |> filter(reader_number == 1) |> nrow())
  message("  Number of records by reader 2: ", reader_df |> filter(reader_number == 2) |> nrow())
  message("  Number of episodes in reader records: ", num_episodes(reader_df))
  stopifnot(reader_df |> filter(reader_number == 1) |> nrow() == num_episodes(reader_df))
  stopifnot(reader_df |> filter(reader_number == 2) |> nrow() == num_episodes(reader_df))
  reader_df
}


#' Save clean data to disk
#' @param model_df A data frame. The model data frame.
#' @param reader_df A data frame. The reader data frame.
#' @param is_test TRUE / FALSE; whether the input files are from the testing / developing set.
#' @param output_directory A string; the path to the output directory.
save_clean_data_to_disk <- function(model_df, reader_df, is_test, output_directory) {
  message_heading("Saving clean data to disk")
  # Create placeholder data frame for the simulation
  message("  Creating the placeholder data frame for the simulation")
  accession_df <- model_df |>
    select(episode_id, episode_outcome) |>
    mutate(episode_prediction = NA_real_, by = NA_character_, decided = FALSE)

  # Save the clean data into files
  suffix <- ifelse(is_test, "", "-dev")
  as_RDS <- \(x) paste0(file.path(output_directory, x), suffix, ".RDS")
  as_CSV <- \(x) paste0(file.path(output_directory, x), suffix, ".csv")
  message("  Creating the 'model_df', 'reader_df' and 'accession_df' variables")

  saveRDS(model_df, file = as_RDS("model_df"))
  saveRDS(reader_df, file = as_RDS("reader_df"))
  saveRDS(accession_df, file = as_RDS("accession_df"))

  message("  Keeping a log of the clean records")
  log_path <- as_CSV("model_df_clean")
  write.csv(model_df, log_path, row.names = F)
  message("  File written to: ", log_path)

  log_path <- as_CSV("reader_df_clean")
  write.csv(reader_df, log_path, row.names = F)
  message("  File written to: ", log_path)
}
