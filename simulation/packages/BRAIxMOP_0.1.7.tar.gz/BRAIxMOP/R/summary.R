#' Confusion matrix
#'
#' @param episode_df0 A data frame; the data frame containing the model prediction.
#' The model prediction should be binary.
#'
#' @return A named list with attributes TP, FP, TN, FN, P, N, TPR, FPR, TNR, FNR.
#'
#' @export
confusion_matrix <- function(episode_df0) {
  stopifnot(length(unique(episode_df0$episode_prediction)) <= 2)

  stable <- episode_df0 |>
    mutate(episode_outcome = 1.0 * (episode_outcome %in% c(1, 2))) |>
    mutate(episode_prediction = episode_prediction) |>
    group_by(episode_prediction, episode_outcome) |>
    summarise(count = n(), .groups = "drop")

  get_count <- function(pred, outcome) {
    stable |>
      filter(episode_prediction == pred, episode_outcome == outcome) |>
      extract2("count") |>
      zero_if_empty()
  }

  zero_if_empty <- function(x) if (length(x) == 0) 0 else x

  res <- list(
    TP = get_count(1, 1), FP = get_count(1, 0),
    FN = get_count(0, 1), TN = get_count(0, 0),
    P = get_count(1, 1) + get_count(0, 1),
    N = get_count(1, 0) + get_count(0, 0)
  )
  res$TPR <- res$TP / max(res$P, 1e-10) # avoid division by zero
  res$FNR <- 1 - res$TPR
  res$TNR <- res$TN / max(res$N, 1e-10)
  res$FPR <- 1 - res$TNR
  res
}
