#' Whether the unit of a data frame is episode
#'
#' @param df0 A data frame.
#'
#' @return TRUE / FALSE; whether the unit of a data frame is episode.
#'
#' @export
is_unit_episode <- function(df0) {
  nrow(df0) == num_episodes(df0)
}


is_cancer <- function(xs) {
  xs %in% c(1, 2)
}
