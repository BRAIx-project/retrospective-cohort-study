#' Get reader performance for matching
#'
#' @param reader_file A character string; the path to the reader RDS file.
#' @param is_test TRUE / FALSE; whether the input files are from the testing / developing set.
#' @param output_directory A character string; the path to the output directory.
#' @param ... Additional arguments to pass to `get_reader_summary`.
#'
#' @export
get_reader_performance_for_matching <- function(reader_file, is_test, output_directory, ...) {
  label <- ifelse(is_test, "testing", "developing")
  message(glue("Computing the {yellow(label)} reader performance for matching"))

  reader_df <- readRDS(reader_file)
  reader_sum <- get_reader_summary(reader_df, ...)
  fname <- ifelse(is_test,
                  "reader_performance.RDS",
                  "reader_performance-dev.RDS")
  save_RDS(reader_sum,
           file.path(output_directory, fname),
           "Saving the weighted mean of the readers performance")
  reader_sum
}




#' Find the operating point / threshold at which the AI will match the reader
#' specificity and compute the performance at that threshold
#'
#' @param model_df A data frame; the model predictions.
#' @param reader_performance A data frame; the reader performance.
#' @param output_directory A character string; the path to the output directory.
#' @param fast TRUE / FALSE; whether to use the fast method. See details.
#' @param search_grid A vector of specificities to search for the target specificities.
#' It is used only when fast == FALSE. The root-finding algorithm is used if
#' the search grid is not provided.
#'
#' @details
#' There are two ways to match the reader specificity. The first one is to use
#' the target specificity as the input for the manufacturer specific
#' matching and let the outcome specificity vary, or we can optimise the input to
#' match the outcome specificity to the target specificity. They produce almost
#' identical outcomes. The first one runs much faster (>>10X), and the second
#' one is technically more appropriate.
#'
#' @return A list; the threshold, the thresholded model, and the performance.
#' @export
get_ai_threshold_and_performance <- function(model_df,
                                             reader_performance,
                                             output_directory,
                                             fast = TRUE,
                                             search_grid) {
  target_sens <- reader_performance$mean_reader$weighted_tpr
  target_spec <- 1 - reader_performance$mean_reader$weighted_fpr
  if (fast) {
    thr <- find_manufacturer_threshold_matching(
      model_df, target = "specificities", target_value = target_spec
    )
    model_thresholded_df <- apply_manufacturer_threshold(model_df, thr)
    model_performance <- data.frame(confusion_matrix(model_thresholded_df))

    result <- list(
      match_specificity = target_spec,
      threshold = thr,
      model_thresholded_df = model_thresholded_df,
      model_performance = model_performance
    )
  } else {
    if (missing(search_grid)) {
      # "Root-finding"
      inv_logit <- \(x) 1 / (1 + exp(-x))

      f <- function(tar_thr) {
        tar_thr_01 <- inv_logit(tar_thr)
        thr <- find_manufacturer_threshold_matching(
          model_df, target = "specificities", target_value = tar_thr_01
        )
        model_thresholded_df <- apply_manufacturer_threshold(model_df, thr)
        confusion_matrix(model_thresholded_df)
      }

      loss <- function(opt_thr) {
        (f(opt_thr)$TNR - target_spec)^2
      }

      optim_result <- optim(0.9, loss, method = "BFGS")

      s <- inv_logit(optim_result$par)
      thr <- find_manufacturer_threshold_matching(model_df, target = "specificities", target_value = s)
      model_thresholded_df <- apply_manufacturer_threshold(model_df, thr)
      model_performance <- data.frame(confusion_matrix(model_thresholded_df))

      result <- list(
        match_specificity = s,
        threshold = thr,
        model_thresholded_df = model_thresholded_df,
        model_performance = model_performance,
        optim = optim_result
      )
    } else {
      search_result <- do.call(
        rbind,
        lapply(
          search_grid,
          function(spec) {
            thr <- find_manufacturer_threshold_matching(
              model_df, target = "specificities", target_value = spec
            )
            model_thresholded_df <- apply_manufacturer_threshold(model_df, thr)
            data.frame(confusion_matrix(model_thresholded_df))
          }
        )
      )

      best_ind <- which.max(abs(search_result$TPR + search_result$TNR - 1) *
                              (search_result$TNR >= target_spec) *
                              (search_result$TPR >= target_sens))
      if (all(search_result$TNR < target_spec | search_result$TPR < target_sens)) {
        warning(gsub(
          sprintf("No point on the search grid produces (both) sensitivity and
                  specificity at least as good as the target (%s, %s), the closest
                  one will be used instead.", round(target_sens, 4), round(target_spec, 4)),
          replacement = " ", pattern = "\n"
        ))
        best_ind <- which.min(abs(search_result$TNR - target_spec))
      }
      best_result <- search_result[best_ind, ]

      s <- search_grid[best_ind]
      thr <- find_manufacturer_threshold_matching(model_df, target = "specificities", target_value = s)
      model_thresholded_df <- apply_manufacturer_threshold(model_df, thr)
      model_performance <- data.frame(confusion_matrix(model_thresholded_df))

      result <- list(
        match_specificity = s,
        threshold = thr,
        model_thresholded_df = model_thresholded_df,
        model_performance = model_performance,
        search_grid = search_grid,
        search_log = search_result
      )
    }
  }

  if (!is.null(output_directory)) {
    save_RDS(result,
             file.path(output_directory, "AI_performance.RDS"),
             "Saving the thresholds and performance of AI readers.")
  }
  result
}




#' Find the operating point / threshold at which the AI will match target
#' specificity and sensitivity and compute the performance at that threshold (Band-pass scenario)
#'
#' @param model_df A data frame; the model predictions.
#' @param target A list of TPR and TNR.
#' @param output_directory A character string; the path to the output directory.
#' @param accession_df A data frame; the placeholder for storing the simulation result.
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param search_grid A numeric vector; the grid of input specificities to search for.
#'
#' @return A list; the threshold, the thresholded model, and the performance.
#' @export
get_ai_threshold_and_performance_bandpass <- function(model_df,
                                                      target,
                                                      output_directory,
                                                      accession_df,
                                                      reader_df,
                                                      search_grid) {
  message("Pre-applying thresholds")
  tictoc::tic()
  ss <- sort(search_grid)  # increasing order of specificities
  model_thresholded_dfs <- lapply(ss, function(tar_thr) {
    thr <- find_manufacturer_threshold_matching(model_df, "specificities", tar_thr)
    model_thresholded_df <- apply_manufacturer_threshold(model_df, thr)
    attr(model_thresholded_df, "threshold") <- thr
    model_thresholded_df
  })
  tictoc::toc()

  message("Finding thresholds")
  # Double loop over grid of specificities / thresholded models
  l <- length(ss)
  result <- vector("list", l * (l - 1) / 2)
  m <- 1
  for (i in 1:(length(ss) - 1)) {
    tictoc::tic()
    m_low <- model_thresholded_dfs[[i]]
    for (j in (i+1):length(ss)) {
      # Need to be careful which one is the high band and which one is the
      # low band. High band AI reader has a high threshold, making fewer cancer
      # classification than the low band AI reader, which has a low threshold.
      # Hence, the high band reader is more specific / corresponds to the high
      # specificities.
      m_high <- model_thresholded_dfs[[j]]
      sim <- AI_band_pass_screening_ms(accession_df, reader_df, m_low, m_high, rep(0.5, 2))
      sim_summary <- scenario_summary(sim)
      sim_performance <- data.frame(sim_summary$performance)
      sim_econ <- band_pass_screening_economics(sim_summary)
      result[[m]] <- data.frame(i = i, j = j, si = ss[i], sj = ss[j],
                                sim_performance,
                                third_reads = sim_econ$cost_drivers$human_readings$reader_3_reads,
                                total_cost = sim_econ$cost$total_cost$total)
      m <- m + 1
    }
    pb <- tictoc::toc()
    message(
      "Remaining iteration: ", (l - i), ". ",
      "Estimated remaining time: ", round((l - i) * (pb$toc - pb$tic) / 60, 2), " minutes."
    )
  }

  search_result <- do.call(rbind, result)
  # Here we match the target specificities. It is possible to consider other
  # criteria for matching.
  target_sens <- target$TPR
  target_spec <- target$TNR
  best_ind <- which.max(abs(search_result$TPR + search_result$TNR - 1) *
                          (search_result$TNR >= target_spec) *
                          (search_result$TPR >= target_sens))
  if (all(search_result$TNR < target_spec) || all(search_result$TPR < target_sens)) {
    warning("No point on the search grid produces (both) sensitivity and specificity at least as good as the target, the closest one will be used instead.")
    best_ind <- which.min(abs(search_result$TNR - target_spec))
  }
  best_result <- search_result[best_ind, ]

  joined_result <- list(
    low_band_threshold = find_manufacturer_threshold_matching(model_df, "specificities", best_result$si),
    high_band_threshold = find_manufacturer_threshold_matching(model_df, "specificities", best_result$sj),
    model_performance = best_result,
    search_log = search_result
  )

  if (!is.null(output_directory)) {
    save_RDS(joined_result,
             file.path(output_directory, "AI_performance_bandpass.RDS"),
             "Saving the thresholds and performance of AI readers for the band-pass scenario.")
  }
  joined_result
}
