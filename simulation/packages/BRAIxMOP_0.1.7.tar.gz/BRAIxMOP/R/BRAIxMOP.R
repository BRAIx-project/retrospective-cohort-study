#' Model Operating Point analysis
#' @name BRAIxMOP
#' @import dplyr
#' @importFrom tidyr nest unnest
#' @importFrom utils capture.output read.csv write.csv head tail
#' @importFrom stats setNames optim
#' @importFrom glue glue
utils::globalVariables(c(
  "episode_id", "episode_outcome", "episode_prediction",
  "laterality_prediction",
  "image_laterality", "image_prediction",
  "reader_number", "reader_id",
  "individual_recall", "consensus_recall",
  "decided", "data", "weights", "TPR", "FPR", "n_reads",
  "manufacturer", "algorithm",
  "benefit.TP", "benefit.TN",
  "harms.FP", "harms.FN",
  "cost_drivers.assessments.total",
  "cost.total_cost.reading",
  "cost.total_cost.assessment",
  "cost.total_cost.total",
  "cost_drivers.human_readings.total_reads",
  "num_data", "is_better",
  "."
))
