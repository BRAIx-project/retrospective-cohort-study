#' Baseline scenario
#'
#' @description The scenario corresponding to the existing screening pathway.
#' The three readers classify the episodes based on the "individual_recall"
#' column from the database.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#'
#' @return A data frame; the result of the scenario simulation.
#'
#' @export
baseline <- function(accession_df, reader_df) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)
}


#' Summary of a scenario
#'
#' @param res A data frame; the output from the scenario simulation.
#'
#' @return A list; the summary of the scenario.
#'
#' @export
scenario_summary <- function(res) {
  # Recall / no recall summary
  summary <- res |>
    group_by(episode_prediction, by) |>
    summarise(count = n())

  # Recall / no recall summary by sub-categories
  summary_by_outcome <- res |>
    group_by(episode_prediction, by, episode_outcome) |>
    summarise(count = n())

  # System performance
  performance <- confusion_matrix(res)

  list(result = res,
       summary = summary,
       summary_by_outcome = summary_by_outcome,
       performance = performance,
       extra = attr(res, "extra"))
}


# 2023-09-05 ===================================================================
#' MASAI simulation
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai <- function(accession_df, reader_df, model_pred, threshold) {
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  first_pass <- ai_reader(accession_df)
  first_pass_double <- first_pass |> filter(episode_prediction == 1)
  first_pass_single <- first_pass |> filter(episode_prediction == 0)

  double_read <- reader_1(first_pass_double) |>
    merge_two_readers(reader_2(first_pass_double), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)

  from_reader_1 <- sample(c(T, F), nrow(first_pass_single), replace = TRUE)
  single_reader_1 <- reader_1(first_pass_single, final_decision = TRUE)
  single_reader_2 <- reader_2(first_pass_single, final_decision = TRUE)
  single_read <- rbind(single_reader_1[from_reader_1, ],
                       single_reader_2[!from_reader_1, ])
  rbind(single_read, double_read)
}


# 2023-06-22 ===================================================================
#' AI replacement with second reader as third reader when the episodes are not available
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_random_second_reader_arbiter <- function(accession_df, reader_df, model_pred, threshold, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
  reader_13 <- reader_n3(reader_df, 1, "mixed-reader-13")
  reader_23 <- reader_n3(reader_df, 2, "mixed-reader-23")

  extract <- `[`

  from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)

  accession_df_grp_1 <- reader_1(accession_df) |>
    merge_two_readers(ai_reader(accession_df), id = "reader-1-and-AI") |>
    reader_23(final_decision = TRUE) |>
    extract(from_reader_1, )

  accession_df_grp_2 <- reader_2(accession_df) |>
    merge_two_readers(ai_reader(accession_df), id = "reader-2-and-AI") |>
    reader_13(final_decision = TRUE) |>
    extract(!from_reader_1, )

  rbind(accession_df_grp_1, accession_df_grp_2)
}


#' AI replacement with mixed-simulated third reader
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_random_mixed_sim <- function(accession_df, reader_df, model_pred, threshold, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
  reader_3 <- mixed_reader(reader_df, 3, "mixed-reader-3", ...)

  from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)

  accession_df_grp_1 <- merge_two_readers(
    reader_1(accession_df),
    ai_reader(accession_df),
    id = "reader-1-and-AI"
  )[from_reader_1, ]

  accession_df_grp_2 <- merge_two_readers(
    reader_2(accession_df),
    ai_reader(accession_df),
    id = "reader-2-and-AI"
  )[!from_reader_1, ]

  rbind(accession_df_grp_1, accession_df_grp_2) |>
    reader_3(final_decision = TRUE)
}


# 2022-10-26 ===================================================================
#' Baseline scenario with simulated third reader
#'
#' @description This scenario verifies that the third reader is simulated in a
#' way that the consensus performance is close to the real data.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_pred A data frame; the data frame containing the model prediction.
#' @param threshold A scalar; the threshold for the model prediction.
#' @param ... Additional arguments to be passed to the simulated reader.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_baseline_check <- function(accession_df, reader_df, model_pred, threshold, ...) {
  message("Threshold is not used in this scenario.")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3", ...)

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)
}


# 2022-06-06 New scenario ======================================================
# Band-Pass independent = Band Pass + Reader 3
#' Band-pass screening with independent simulated third reader
#'
#' @description This scenario simulates the band-pass screening with one AI reader
#' at the front and one simulated reader (based on reader 3 performance) at the end.
#'
#' @param threshold A vector of length 2; the band-pass thresholds for the model prediction.
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_band_pass_independent <- function(accession_df, reader_df, model_pred, threshold) {
  stopifnot(length(threshold) == 2)

  low_band_reader <- AI_reader(model_pred, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_pred, threshold[2], "AI-reader")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  first_pass <- low_band_reader(accession_df)
  first_pass_recall <- first_pass |> filter(episode_prediction == 1)
  first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
  first_pass_no_recall$decided <- TRUE

  second_pass <- high_band_reader(first_pass_recall)
  second_pass_recall <- second_pass |> filter(episode_prediction == 1)
  second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
  second_pass_recall$decided <- TRUE

  third_read <- reader_3(second_pass_no_recall, final_decision = TRUE)
  rbind(first_pass_no_recall, second_pass_recall, third_read)
}


# Band-Pass screening = Band Pass + Reader 1,2 + Reader 3
#' Band-pass screening followed by standard pathway
#'
#' @param threshold A vector of length 2; the band-pass thresholds for the model prediction.
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_band_pass_screening <- function(accession_df, reader_df, model_pred, threshold) {
  stopifnot(length(threshold) == 2)

  low_band_reader <- AI_reader(model_pred, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_pred, threshold[2], "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  first_pass <- low_band_reader(accession_df)
  first_pass_recall <- first_pass |> filter(episode_prediction == 1)
  first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
  first_pass_no_recall$decided <- TRUE

  second_pass <- high_band_reader(first_pass_recall)
  second_pass_recall <- second_pass |> filter(episode_prediction == 1)
  second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
  second_pass_recall$decided <- TRUE

  pass_read <- reader_1(second_pass_no_recall) |>
    merge_two_readers(reader_2(second_pass_no_recall), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)

  rbind(first_pass_no_recall, second_pass_recall, pass_read)
}


# Band-pass screening manufacturer specific thresholds
#' Band-pass screening with manufacturer specific thresholds
#'
#' @description This scenario is the same as `AI_band_pass_screening` except that
#' the thresholds are different for each manufacturer.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_pred A data frame; the data frame containing the model prediction that
#' has been thresholded by the manufacturer specific thresholds.
#' @param model_pred_2 A data frame; the data frame containing the model prediction that
#' has been thresholded by the manufacturer specific thresholds.
#' @param threshold A vector of length 2; the band-pass thresholds for the model prediction.
#' In this case, the argument is only a dummy variable to be consistent with the other
#' scenarios. The thresholds are already applied to the model prediction.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_band_pass_screening_ms <- function(accession_df, reader_df, model_pred, model_pred_2, threshold) {
  stopifnot(length(threshold) == 2)

  low_band_reader <- AI_reader(model_pred, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_pred_2, threshold[2], "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  first_pass <- low_band_reader(accession_df)
  first_pass_recall <- first_pass |> filter(episode_prediction == 1)
  first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
  first_pass_no_recall$decided <- TRUE

  second_pass <- high_band_reader(first_pass_recall)
  second_pass_recall <- second_pass |> filter(episode_prediction == 1)
  second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
  second_pass_recall$decided <- TRUE

  pass_read <- reader_1(second_pass_no_recall) |>
    merge_two_readers(reader_2(second_pass_no_recall), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)

  rbind(first_pass_no_recall, second_pass_recall, pass_read)
}


# AI replaces both reader 2 and 3
#' AI replacement of reader 2 and 3
#'
#' @description This scenario replaces the second and third reader with the AI reader.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_pred A data frame; the data frame containing the model prediction.
#' @param threshold A scalar; the threshold for the model prediction.
#' @param threshold_2 A scalar; the threshold for the model prediction.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_replacement_2_and_3 <- function(accession_df, reader_df, model_pred, threshold, threshold_2) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold, "AI-reader-2")
  reader_3 <- AI_reader(model_pred, threshold_2, "AI-reader-3")

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-AI") |>
    reader_3(final_decision = TRUE)
}


#===============================================================================
# Scenario 1a
#' AI autonomous screening (ideal)
#'
#' @description This scenario includes an AI reader at the beginning of the reading
#' pathway and then the three readers. The AI reader is allowed to make a final
#' decision.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_autonomous_screening_ideal <- function(accession_df, reader_df, model_pred, threshold = 0.05) {
  reader_0 <- AI_reader(model_pred, threshold, "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)
  accession_no_recall$decided <- TRUE

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2"),
    final_decision = TRUE
  )

  rbind(third_read, accession_no_recall)
}

# Scenario 1b
#' AI autonomous screening (practical)
#'
#' @description This scenario is the same as `AI_autonomous_screening_ideal` except that
#' the AI reader is not allowed to make a final decision. The no-recall episodes are
#' checked by a simulated fourth reader that is based on the performance of the first reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_autonomous_screening_practical <- function(accession_df, reader_df, model_pred, threshold = 0.05) {
  reader_0 <- AI_reader(model_pred, threshold, "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")
  reader_4 <- simulated_reader(reader_df, 1, "reader-4")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2"),
    final_decision = TRUE
  )

  rbind(third_read, reader_4(accession_no_recall, final_decision = TRUE))
}

# Scenario 2a - replace reader 2
#' AI independent reading
#'
#' @description This scenario replaces the second reader with the AI reader.
#' The third reads are simulated based on the empirical performance of the third reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent <- function(accession_df, reader_df, model_pred, threshold = 0.05, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold, "AI-reader-2")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3", ...)

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-AI") |>
    reader_3(final_decision = TRUE)
}

# Scenario 2b - replace reader 3
#' AI independent reading
#'
#' @description This scenario replaces the third reader with the AI reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_3 <- function(accession_df, reader_df, model_pred, threshold = 0.05) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- AI_reader(model_pred, threshold, "AI-reader-3")

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)
}

# Scenario 2c - replace reader 1
#' AI independent reading
#'
#' @description This scenario replaces the first reader with the AI reader.
#' The third reads are simulated based on the empirical performance of the third reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_1 <- function(accession_df, reader_df, model_pred, threshold = 0.05, ...) {
  reader_1 <- AI_reader(model_pred, threshold, "AI-reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3", ...)

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-2-and-AI") |>
    reader_3(final_decision = TRUE)
}

# Scenario 2d - randomly replace reader 1 or 2
#' AI independent reading
#'
#' @description This scenario replaces the first or second reader (randomly with 50/50 probabilities)
#' with the AI reader. The third reads are simulated based on the empirical performance of the third reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_random <- function(accession_df, reader_df, model_pred, threshold = 0.05, ...) {
  result_1 <- AI_independent_replace_1(accession_df, reader_df, model_pred, threshold, ...)
  result_2 <- AI_independent(accession_df, reader_df, model_pred, threshold, ...)
  from_reader_1 <- sample(c(T, F), nrow(result_1), replace = TRUE)
  stopifnot(all(result_1$episode_id == result_2$episode_id))
  rbind(
    result_1[which(from_reader_1), ],
    result_2[which(!from_reader_1), ]
  ) |>
    arrange(episode_id)
}

# Scenario 5
#' AI final-pass reading
#'
#' @description This scenario adds an AI reader at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_final_pass <- function(accession_df, reader_df, model_pred, threshold = 0.8) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")
  reader_4 <- AI_reader(model_pred, threshold, "AI-reader")

  first_read <- reader_1(accession_df)
  second_read <- reader_2(accession_df)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2")
  )

  accession_recall <- third_read |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- third_read |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))
  attr(res, "extra") <- list(
    n_reader_3 = third_read |> filter(by == "reader-3") |> nrow()
  )
  res
}

# Scenario 6 - AI autonomous screening (ideal) + AI independent ----------------
#' AI autonomous screening (ideal) + AI independent
#'
#' @description This scenario adds an AI reader at the beginning of the standard pathway,
#' and replaces the second reader with the AI reader.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of two numbers, the first is the threshold for the AI
#' autonomous screening, and the second is the threshold for the AI independent reading.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_independent <- function(accession_df, reader_df, model_pred, threshold = c(0.05, 0.05)) {
  stopifnot(length(threshold) == 2)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")

  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold[2], "AI-reader-independent")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)
  accession_no_recall$decided <- TRUE

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2"),
    final_decision = TRUE
  )

  rbind(third_read, accession_no_recall)
}


# Scenario 7 - AI autonomous screening (ideal) + final pass --------------------
#' AI autonomous screening (ideal) + final pass
#'
#' @description This scenario adds an AI reader at the beginning of the standard pathway,
#' and adds an AI reader at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of two numbers, the first is the threshold for the AI
#' autonomous screening, and the second is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_final_pass <- function(accession_df, reader_df, model_pred, threshold = c(0.05, 0.8)) {
  stopifnot(length(threshold) == 2)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")

  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  reader_4 <- AI_reader(model_pred, threshold[2], "AI-reader-final-pass")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2")
  )

  autonomous <- rbind(third_read, accession_no_recall)
  accession_recall <- autonomous |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- autonomous |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))

  # Add extra information from the intermediate stages that cannot be recovered
  # at the end of the simulation.
  attr(res, "extra") <- list(
    screening_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 1) |>
      nrow(),
    screening_no_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 0) |>
      nrow(),
    n_reader_3 = third_read |> filter(by == "reader-3") |> nrow()
  )
  res
}


# Scenario 8 - AI independent reader 2 + final pass ----------------------------
#' AI independent reader 2 + final pass
#'
#' @description This scenario replaces the second reader with an AI reader, and adds
#' an AI reader at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of two numbers, the first is the threshold for the AI
#' independent reading, and the second is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
independent_final_pass <- function(accession_df, reader_df, model_pred, threshold = c(0.05, 0.8)) {
  stopifnot(length(threshold) == 2)
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold[1], "AI-reader-independent")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  reader_4 <- AI_reader(model_pred, threshold[2], "AI-reader-final-pass")

  first_read <- reader_1(accession_df)
  second_read <- reader_2(accession_df)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-AI"),
    final_decision = FALSE
  )

  accession_recall <- third_read |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- third_read |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))
  attr(res, "extra") <- list(
    n_reader_3 = third_read |> filter(by == "sim-reader-3") |> nrow()
  )
  res
}


# Scenario 9 - AI autonomous screening (ideal) + AI independent + final pass ----
#' AI autonomous screening (ideal) + AI independent + final pass
#'
#' @description This scenario adds an AI reader at the beginning of the standard pathway,
#' replaces the second reader with an AI reader, and adds an AI reader at the end of
#' the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of three numbers, the first is the threshold for the AI
#' autonomous screening, the second is the threshold for the AI independent reading,
#' and the third is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_independent_final_pass <- function(accession_df, reader_df, model_pred,
                                              threshold = c(0.05, 0.05, 0.8)) {
  stopifnot(length(threshold) == 3)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")

  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold[2], "AI-reader-independent")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  reader_4 <- AI_reader(model_pred, threshold[3], "AI-reader-final-pass")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-AI")
  )

  autonomous <- rbind(third_read, accession_no_recall)
  accession_recall <- autonomous |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- autonomous |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))

  # Add extra information from the intermediate stages that cannot be recovered
  # at the end of the simulation.
  attr(res, "extra") <- list(
    screening_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 1) |>
      nrow(),
    screening_no_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 0) |>
      nrow(),
    n_reader_3 = third_read |> filter(by == "sim-reader-3") |> nrow()
  )
  res
}


# Scenario 9b - AI autonomous screening (ideal) + single AI independent + final pass ----
#' AI autonomous screening (ideal) + single AI independent + final pass
#'
#' @description This scenario replaces the standard pathway with a single AI reader, and
#' adds an AI reader at the beginning and at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of three numbers, the first is the threshold for the AI
#' autonomous screening, the second is the threshold for the AI independent reading,
#' and the third is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_single_independent_final_pass <- function(accession_df, reader_df, model_pred,
                                                     threshold = c(0.05, 0.05, 0.8)) {
  stopifnot(length(threshold) == 3)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")
  reader_2 <- AI_reader(model_pred, threshold[2], "AI-reader-independent")
  reader_4 <- AI_reader(model_pred, threshold[3], "AI-reader-final-pass")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  middle_read <- reader_2(accession_recall)

  autonomous <- rbind(middle_read, accession_no_recall)
  accession_recall <- autonomous |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- autonomous |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall,
               reader_4(accession_no_recall, final_decision = TRUE))

  # Add extra information from the intermediate stages that cannot be recovered
  # at the end of the simulation.
  attr(res, "extra") <- list(
    screening_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 1) |>
      nrow(),
    screening_no_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 0) |>
      nrow(),
    n_reader = middle_read |> filter(by == "AI-reader-independent") |> nrow()
  )
  res
}
