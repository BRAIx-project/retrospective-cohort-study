#' A simulated reader that uses the ground truth as prediction
#'
#' @param model_df A data frame; the data frame containing the model episode predictions.
#' @param id A character string; the name given to the reader.
#'
#' @export
oracle_reader <- function(model_df, id) {
  required_cols <- c("episode_id", "episode_outcome")
  stopifnot(all(required_cols %in% colnames(model_df)))

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Threshold the model prediction
    pred_df <- model_df |>
      mutate(episode_prediction = episode_outcome %in% c(1, 2),
             by = id,
             decided = final_decision) |>
      select(episode_id, episode_prediction, by, decided)

    # Update the original data.frame
    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' (Deprecated) The AI model using different thresholds for the manufacturers
#'
#' @param model_df A data frame; the data frame containing the model episode predictions.
#' @param named_threshold A named list or vector of numbers between 0 and 1.
#' @param id A character string; the name given to the reader.
#'
#' @export
#'
#' @note This is deprecated in favour of applying thresholds beforehand, which
#' is much more performant.
AI_adaptive_reader <- function(model_df, named_threshold, id) {
  required_cols <- c("episode_id", "episode_prediction")
  stopifnot(all(required_cols %in% colnames(model_df)))

  threshold_prediction <- function(df0, threshold) {
    for (manufacturer in names(threshold)) {
      ind <- which(df0$image_manufacturer == manufacturer)
      thres <- threshold[[manufacturer]]
      df0$episode_prediction[ind] <- df0$episode_prediction[ind] > thres
    }
    df0$episode_prediction
  }

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Threshold the model prediction
    pred_df <- model_df |>
      mutate(episode_prediction = threshold_prediction(model_df, named_threshold),
             by = id,
             decided = final_decision) |>
      select(episode_id, episode_prediction, by, decided)

    # Update the original data.frame
    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' The AI model
#'
#' @param model_df A data frame; the data frame containing the model episode predictions.
#' @param threshold A number between 0 and 1; the threshold above which the prediction score is classified as cancer.
#' @param id A character string; the name given to the reader.
#'
#' @export
AI_reader <- function(model_df, threshold, id) {
  required_cols <- c("episode_id", "episode_prediction")
  stopifnot(all(required_cols %in% colnames(model_df)))

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Threshold the model prediction
    pred_df <- model_df |>
      mutate(episode_prediction = episode_prediction > threshold,
             by = id,
             decided = final_decision) |>
      select(episode_id, episode_prediction, by, decided)

    # Update the original data.frame
    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' Readers from the actual database
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#'
#' @export
admani_reader <- function(reader_df, reader_position, id) {
  reader_df <- reader_df |>
    filter(reader_number == reader_position)
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Use database entry as prediction
    pred_df <- reader_df |>
      select(episode_id, individual_recall) |>
      rename(episode_prediction = individual_recall) |>
      mutate(by = id, decided = final_decision)

    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' A reader simulated based on empirical performance
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#' @param custom A numeric vector corresponding to the probabilities of classifying the episodes
#' as cancers when the labels are 0 (normal), 1 (screen-detected cancer), 2 (interval cancer),
#' 3 (benign), 4 (no significant abnormality). Examples include: c(0, 1, 0.2, 1, 1);
#' c(0, 1, 0.25, 1, 1), c(0, 1, 0.3, 1, 1), c(0.446, 0.958, 0.958, 0.446, 0.446) (pooled labels).
#'
#' @export
simulated_reader <- function(reader_df, reader_position, id, custom) {
  reader_emp_perf <- reader_df |>
    filter(reader_number == reader_position) |>
    select(episode_outcome, individual_recall) |>
    group_by(episode_outcome, individual_recall) |>
    summarise(count = n()) |>
    rename(episode_prediction = individual_recall)

  probs <- reader_emp_perf |>
    group_by(episode_outcome) |>
    mutate(prob = count / sum(count)) |>
    filter(episode_prediction == 1)

  probs <- setNames(probs$prob, probs$episode_outcome)

  # Make sure all outcomes have empirical probabilities attached to them
  for (outcome_label in as.character(0:4)) {
    if (is.na(probs[outcome_label])) {
      probs[outcome_label] <- 0
    }
  }

  if (!missing(custom)) {
    stopifnot(length(custom) == 5)
    probs['0'] <- custom[1]
    probs['1'] <- custom[2]
    probs['2'] <- custom[3]
    probs['3'] <- custom[4]
    probs['4'] <- custom[5]
  }
  message("Probabilities used for each label:")
  print(probs)

  predict_empirical <- Vectorize(function(outcome) {
    p <- probs[[as.character(outcome)]]
    sample(c(0, 1), size = 1, prob = c(1 - p, p))
  })

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Simulate outcome using the empirical distribution
    accession_df$episode_prediction[ind] <- predict_empirical(accession_df$episode_outcome[ind])
    accession_df$by[ind] <- id
    accession_df$decided[ind] <- final_decision
    accession_df
  }
}


#' Merge the results from two readers
#'
#' @description When two readers agree with each other, set the `decided` flag to TRUE.
#' Otherwise, set `decided` to FALSE and the episode prediction to be 1 or -1.
#' where 1 refers to when reader 1 indicates cancer, when -1 refers to when
#' reader 2 indicates cancer.
#'
#' @param reader_1_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_2_df A data frame; the data frame containing the reader's episode predictions.
#' @param ind A integer vector; the row numbers to be updated.
#' @param id A character string; the name given to the reader.
merge_two_readers <- function(reader_1_df, reader_2_df, ind, id) {
  if (missing(ind)) {
    ind <- which(reader_1_df$decided == FALSE)
  }
  merged_reader <- reader_1_df

  agree <- reader_1_df$episode_prediction[ind] == reader_2_df$episode_prediction[ind]
  merged_reader$by[ind] <- id
  merged_reader[ind, ][which(agree), ]$decided <- TRUE

  reader_1_reads <- reader_1_df[ind, ][which(!agree), ]$episode_prediction
  reader_2_reads <- reader_2_df[ind, ][which(!agree), ]$episode_prediction
  merged_reader[ind, ][which(!agree), ]$episode_prediction <- reader_1_reads - reader_2_reads
  merged_reader[ind, ][which(!agree), ]$decided <- FALSE

  merged_reader
}


# 2023-06-22 ===================================================================
#' A reader that uses the actual database when possible and simulates when not
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#' @param custom A numeric vector for the simulated reader, corresponding to the
#' probabilities of classifying the episodes as cancers when the labels are 0
#' (normal), 1 (screen-detected cancer), 2 (interval cancer), 3 (benign), 4 (no
#' significant abnormality). Examples include: c(0, 1, 0.2, 1, 1); c(0, 1, 0.25,
#' 1, 1), c(0, 1, 0.3, 1, 1) for unpooled labels, and c(0.446, 0.958, 0.958,
#' 0.446, 0.446) for pooled labels.
#'
#' @export
mixed_reader <- function(reader_df, reader_position, id, custom) {
  available_episodes <- reader_df |>
    filter(reader_number == reader_position) |>
    extract2("episode_id") |>
    unique()

  actual <- admani_reader(reader_df, reader_position, paste0(id, "(data)"))
  sim <- simulated_reader(reader_df, reader_position, paste0(id, "(sim)"), custom)
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    available_in_db <- accession_df$episode_id[ind] %in% available_episodes
    ind_available <- ind[available_in_db]
    ind_unavailable <- ind[!available_in_db]

    accession_df |>
      actual(ind_available, final_decision) |>
      sim(ind_unavailable, final_decision)
  }
}


#' A third reader that uses the early readers' read if the episodes are not available
#' at the third position.
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1 or 2 only; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#'
#' @export
reader_n3 <- function(reader_df, reader_position, id) {
  stopifnot(reader_position == 1 || reader_position == 2)

  available_episodes <- reader_df |>
    filter(reader_number == 3) |>
    extract2("episode_id") |>
    unique()

  actual <- admani_reader(reader_df, 3, paste0(id, "(true)"))
  subst <- admani_reader(reader_df, reader_position, paste0(id, "(subst)"))
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    available_in_db <- accession_df$episode_id[ind] %in% available_episodes
    ind_available <- ind[available_in_db]
    ind_unavailable <- ind[!available_in_db]

    accession_df |>
      actual(ind_available, final_decision) |>
      subst(ind_unavailable, final_decision)
  }
}



# 2023-09-12 ===================================================================
#' A oracle "reader" that corrects some proportion of the predictions
#'
#' @param prop A number between 0 and 1; the proportion of labels to correct.
#'
#' @export
correction_reader <- function(prop) {
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    miss_ind <- intersect(ind, which(accession_df$episode_outcome != accession_df$episode_prediction))
    corr_ind <- sample(miss_ind, floor(length(miss_ind) * prop))

    if (length(corr_ind) > 0) {
      accession_df$episode_prediction[corr_ind] <- 1 - accession_df$episode_prediction[corr_ind]
    }
    accession_df
  }
}
