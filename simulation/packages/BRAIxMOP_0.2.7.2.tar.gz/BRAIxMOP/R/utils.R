rbind_lapply <- function(xs, f) {
  do.call(rbind, lapply(xs, f))
}

dir_create <- function(dirname) {
  if (!dir.exists(dirname)) {
    message("Directory created:", dirname)
    dir.create(dirname)
  }
}

message_heading <- function(x) {
  message(blue(x))
}

message_table <- function(x) {
  message(paste0(capture.output(x), collapse = "\n"))
}

count <- function(x) {
  length(unique(x))
}

extract2 <- function(x, name) {
  x[[name]]
}


#' Colored terminal output
#' @param x A character string; the input text.
#' @export
yellow <- function(x) {
  paste0("\033[33m", x, "\033[39m")
}


#' Colored terminal output
#' @param x A character string; the input text.
#' @export
blue <- function(x) {
  paste0("\033[34m", x, "\033[39m")
}


#' Serialise an R object
#'
#' @param object R object to serialize.
#' @param path The output path.
#' @param msg Optional message to be printed out.
#'
#' @export
save_RDS <- function(object, path, msg) {
  # Could extend arguments to handle "prefix", "suffix" and "csv" (bool)
  if (!missing(msg)) message(msg)
  message("File written to: ", path)
  saveRDS(object, file = path)
}


#' Convert an RDS file to a JSON file
#'
#' @param path The path to the RDS file.
#'
#' @export
RDS_to_JSON <- function(path) {
  new_path <- gsub("[.]rds$", ".json", path, ignore.case = TRUE)
  path |>
    readRDS() |>
    jsonlite::write_json(new_path, pretty = TRUE, auto_unbox = TRUE)
  message("File written to: ", new_path)
}
