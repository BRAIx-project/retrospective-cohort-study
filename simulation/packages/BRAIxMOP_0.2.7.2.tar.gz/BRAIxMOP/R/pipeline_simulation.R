#' Run simulation analysis with bootstrap
#' @description
#' Run simulation multiple times to generate the bootstrap distribution and CIs
#'
#' @param run_fun A function that runs the simulation.
#' @param bootstrap_n A positive integer; the number of bootstrap samples.
#' @param seed A positive integer; the seed for the random number generator.
#' @param run_parallel A logical; whether to run the simulation in parallel.
#' @param mc.cores A positive integer; the number of cores to use for parallel
#'  computation.
#' @param ... Additional arguments to be passed to \code{run_fun}.
#'
#' @export
run_simulation_bootstrap <- function(run_fun,
                                     bootstrap_n = 1000, seed = 1234,
                                     run_parallel = FALSE, mc.cores = 2,
                                     ...) {
  # Set multi-core
  set_lapply <- function(run_parallel = FALSE, mc.cores = 2) {
    ifelse(run_parallel,
           function(...) parallel::mclapply(mc.cores = mc.cores, ...),
           lapply)
  }
  lapply2 <- set_lapply(run_parallel, mc.cores)

  # Setup
  if (!missing(seed)) set.seed(seed)

  n <- bootstrap_n
  if (n > 10000000) {
    stop("The number of bootstrap is too large: bootstrap_n > 10^7.")
  }

  multiple_runs_seed <- c(seed, sample(10000000, n - 1))
  tracker <- new.env()
  tracker$run <- 1

  args <- list(...)
  args$baseline_result <- run_baseline(args$accession_df, args$reader_df)

  # Main loop
  message("Begin main loop")
  multiple_runs <- multiple_runs_seed |>
    lapply2(function(seed) {
      print(glue::glue("Run: {tracker$run} / {n}"))
      tracker$run <- tracker$run + 1
      args$seed <- seed
      result <- do.call(run_fun, args)
      list(performance = result$system_performance,
           econ = unlist(result$system_econ),
           summary = get_flowchart_reads(result$system_summary$summary),
           summary_by_outcome = get_outcome_reads(
             result$system_summary$summary_by_outcome
           ))
    })

  # Create and save summary
  message("Tidy results")
  multiple_runs_summary <- names(multiple_runs[[1]]) |>
    lapply(\(key) {
      dfs <- lapply(multiple_runs, \(x) x[[key]])
      has_same_number_of_columns <- length(unique(sapply(dfs, ncol))) == 1
      if (!has_same_number_of_columns) {
        common_columns <- Reduce(union, Map(colnames, dfs))
        for (i in seq_along(dfs)) {
          dfs[[i]] <- as.data.frame(dfs[[i]])
          missing_columns <- setdiff(common_columns, colnames(dfs[[i]]))
          dfs[[i]][missing_columns] <- 0
          dfs[[i]] <- dfs[[i]][common_columns]
        }
      }
      do.call(rbind, dfs)
    }) |>
    setNames(names(multiple_runs[[1]]))

  # Return results
  multiple_runs_summary
}


#' Run simulation analysis
#' @description
#' An interface to perform the simulation of the AI replacement scenario and the
#' AI band-pass scenario and compare with the baseline.
#'
#' @param run_fun A function that runs the simulation.
#' @param ... Additional arguments to be passed to \code{run_fun}.
#'
#' @return A list of simulation results.
#' @export
run_simulation <- function(run_fun, ...) {
  args <- list(...)
  args$baseline_result <- run_baseline(args$accession_df, args$reader_df)
  do.call(run_fun, args)
}


#' The baseline scenario
#' @description
#' This function simulates the existing screening pathway.
#'
#' @param accession_df A data frame; the placeholder for storing the simulation result.
#' @param reader_df A data frame; the data frame containing the reader's read.
#'
#' @return A list of simulation results.
#' @export
run_baseline <- function(accession_df, reader_df) {
  res_0 <- baseline(accession_df, reader_df)
  res_0_summary <- scenario_summary(res_0)
  res_0_econ <- baseline_econ <- baseline_economics(res_0_summary)

  device <- animate::animate$new(1000, 800, virtual = TRUE)
  baseline_flowchart(device, baseline_flowchart_data(res_0_summary))
  res_0_flowchart <- animate::rmd_animate(device, options = animate::click_to_loop())

  baseline_result <- list(data = res_0,
                          summary = res_0_summary,
                          econ = res_0_econ,
                          flowchart = res_0_flowchart)
  baseline_result
}


#' The AI replacement scenario. The AI reader replaces one of the first two
#' human readers randomly, and the third reader is simulated.
#'
#' @param accession_df A data frame; the placeholder for storing the simulation result.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_df A data frame; the model predictions.
#' @param threshold The (manufacturer specific) threshold for the replacement scenario.
#' @param seed An integer; the random seed.
#' @param baseline_result The baseline result.
#' @param ... Additional arguments to be passed to \code{AI_independent_replace_random}.
#'
#' @return A list of simulation results.
#' @export
run_AI_replacement <- function(accession_df, reader_df, model_df, threshold, seed, baseline_result, ...) {
  model_thresholded_df <- apply_manufacturer_threshold(model_df, threshold)
  if (!missing(seed)) set.seed(seed)

  message("Replacing reader randomly")
  analysis_api(AI_independent_replace_random,
               AI_independent_random_reader_economics,
               independent_flowchart,
               independent_flowchart_data,
               c("Reader 1", "AI Reader", "Reader 3"),
               "AI reader replacement",
               baseline_econ = baseline_result$econ,
               # actual arguments
               accession_df = accession_df,
               reader_df = reader_df,
               model_pred = model_thresholded_df,
               threshold = 0.5, ...)
}


#' The AI bandpass scenario. The AI reader is added at the beginning of the
#' standard screening pathway.
#'
#' @param accession_df A data frame; the placeholder for storing the simulation result.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_df A data frame; the model predictions.
#' @param threshold_1 The low-band (manufacturer specific) threshold for the band-pass scenario.
#' @param threshold_2 The high-band (manufacturer specific) threshold for the band-pass scenario.
#' @param seed An integer; the random seed.
#' @param baseline_result The baseline result.
#' @param ... Additional arguments to be passed to \code{AI_band_pass_screening_ms}.
#'
#' @return A list of simulation results.
#' @export
run_AI_bandpass <- function(accession_df, reader_df, model_df, threshold_1, threshold_2, seed, baseline_result, ...) {
  model_thresholded_df_1 <- apply_manufacturer_threshold(model_df, threshold_1)
  model_thresholded_df_2 <- apply_manufacturer_threshold(model_df, threshold_2)
  if (!missing(seed)) set.seed(seed)
  # order is (2,1) for sensitivity and (1,2) for specificity
  message("Band-pass scenario")
  analysis_api(AI_band_pass_screening_ms,
               band_pass_screening_economics,
               band_pass_screening_flowchart,
               band_pass_screening_flowchart_data,
               c("Reader 1", "Reader 2", "Reader 3"),
               table_label = "AI band-pass screening",
               baseline_econ = baseline_result$econ,
               # actual arguments
               accession_df = accession_df,
               reader_df = reader_df,
               model_pred = model_thresholded_df_1,
               model_pred_2 = model_thresholded_df_2,
               threshold = rep(0.5, 2), ...)
}


analysis_api <- function(scenario_fun, scenario_econ,
                         scenario_flowchart, scenario_flowchart_data,
                         flowchart_label, table_label, baseline_econ,
                         ...) {
  # # Individual performance
  # individual_perf <- data.frame(confusion_matrix(thresholded_model_pred))

  # System wise performance
  system_sim <- scenario_fun(...)
  system_summary <- scenario_summary(system_sim)
  system_performance <- data.frame(system_summary$performance)

  # Flowchart
  device <- animate::animate$new(1000, 800, virtual = TRUE)
  scenario_flowchart(device, scenario_flowchart_data(system_summary), flowchart_label)
  system_flowchart <- animate::rmd_animate(device, options = animate::click_to_loop())

  # Economics table
  system_econ <- scenario_econ(system_summary)
  system_econ_table <- diff_baseline(baseline_econ, system_econ)|>
    diff_table(table_label)

  list(
    # individual_perf = individual_perf,
    system_summary = system_summary,
    system_performance = system_performance,
    system_flowchart = system_flowchart,
    system_econ = system_econ,
    system_econ_table = system_econ_table
  )
}


# Other helpers
get_flowchart_reads <- function(df0) {
  result <- t(df0$count)
  colnames(result) <- paste(df0$episode_prediction, df0$by, sep = "_")
  result
}

get_outcome_reads <- function(df0) {
  result <- t(df0$count)
  colnames(result) <- paste(df0$episode_prediction,
                            df0$episode_outcome,
                            df0$by,
                            sep = "_")
  result
}
