#' Count the number of episodes in a data frame
#'
#' @param df0 A data frame with the 'episode_id' attribute.
#'
#' @export
num_episodes <- function(df0) {
  count(df0[["episode_id"]])
}


#' Compute the ROC curve of the model data frame
#'
#' @param df0 A data frame; the model data frame.
#'
#' @export
roc <- function(df0) {
  tryCatch({ roc_core(df0) }, error = \(e) NA)
}

roc_core <- function(df0) {
  pROC::roc(1.0 * is_cancer(df0$episode_outcome),
            df0$episode_prediction,
            direction = "<")
}


count_total <- function(x, ...) {
  sum(dplyr::filter(x, ...)[["count"]])
}
