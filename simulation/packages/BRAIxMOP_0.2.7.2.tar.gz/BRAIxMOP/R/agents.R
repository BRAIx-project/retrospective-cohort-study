#' A simulated reader that uses the ground truth as prediction
#'
#' @param model_df A data frame; the data frame containing the model episode predictions.
#' @param id A character string; the name given to the reader.
#'
#' @export
oracle_reader <- function(model_df, id) {
  required_cols <- c("episode_id", "episode_outcome")
  stopifnot(all(required_cols %in% colnames(model_df)))

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Threshold the model prediction
    pred_df <- model_df |>
      mutate(episode_prediction = episode_outcome %in% c(1, 2),
             by = id,
             decided = final_decision) |>
      select(episode_id, episode_prediction, by, decided)

    # Update the original data.frame
    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' (Deprecated) The AI model using different thresholds for the manufacturers
#'
#' @param model_df A data frame; the data frame containing the model episode predictions.
#' @param named_threshold A named list or vector of numbers between 0 and 1.
#' @param id A character string; the name given to the reader.
#'
#' @export
#'
#' @note This is deprecated in favour of applying thresholds beforehand, which
#' is much more performant.
AI_adaptive_reader <- function(model_df, named_threshold, id) {
  required_cols <- c("episode_id", "episode_prediction")
  stopifnot(all(required_cols %in% colnames(model_df)))

  threshold_prediction <- function(df0, threshold) {
    for (manufacturer in names(threshold)) {
      ind <- which(df0$image_manufacturer == manufacturer)
      thres <- threshold[[manufacturer]]
      df0$episode_prediction[ind] <- df0$episode_prediction[ind] > thres
    }
    df0$episode_prediction
  }

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Threshold the model prediction
    pred_df <- model_df |>
      mutate(episode_prediction = threshold_prediction(model_df, named_threshold),
             by = id,
             decided = final_decision) |>
      select(episode_id, episode_prediction, by, decided)

    # Update the original data.frame
    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' The AI model
#'
#' @param model_df A data frame; the data frame containing the model episode predictions.
#' @param threshold A number between 0 and 1; the threshold above which the prediction score is classified as cancer.
#' @param id A character string; the name given to the reader.
#'
#' @export
AI_reader <- function(model_df, threshold, id) {
  required_cols <- c("episode_id", "episode_prediction")
  stopifnot(all(required_cols %in% colnames(model_df)))

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Threshold the model prediction
    pred_df <- model_df |>
      mutate(episode_prediction = episode_prediction > threshold,
             by = id,
             decided = final_decision) |>
      select(episode_id, episode_prediction, by, decided)

    # Update the original data.frame
    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' Readers from the actual database
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#'
#' @export
admani_reader <- function(reader_df, reader_position, id) {
  reader_df <- reader_df |>
    filter(reader_number == reader_position)
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Use database entry as prediction
    pred_df <- reader_df |>
      select(episode_id, individual_recall) |>
      rename(episode_prediction = individual_recall) |>
      mutate(by = id, decided = final_decision)

    accession_df[ind, ] <- accession_df[ind, ] |>
      select(episode_id, episode_outcome) |>
      left_join(pred_df, by = "episode_id")

    accession_df
  }
}


#' A reader simulated based on empirical performance
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#' @param custom A numeric vector corresponding to the probabilities of classifying the episodes
#' as cancers when the labels are 0 (normal), 1 (screen-detected cancer), 2 (interval cancer),
#' 3 (benign), 4 (no significant abnormality). Examples include: c(0, 1, 0.2, 1, 1);
#' c(0, 1, 0.25, 1, 1), c(0, 1, 0.3, 1, 1), c(0.446, 0.958, 0.958, 0.446, 0.446) (pooled labels).
#'
#' @export
simulated_reader <- function(reader_df, reader_position, id, custom) {
  reader_emp_perf <- reader_df |>
    filter(reader_number == reader_position) |>
    select(episode_outcome, individual_recall) |>
    group_by(episode_outcome, individual_recall) |>
    summarise(count = n()) |>
    rename(episode_prediction = individual_recall)

  probs <- reader_emp_perf |>
    group_by(episode_outcome) |>
    mutate(prob = count / sum(count)) |>
    filter(episode_prediction == 1)

  probs <- setNames(probs$prob, probs$episode_outcome)

  # Make sure all outcomes have empirical probabilities attached to them
  for (outcome_label in as.character(0:4)) {
    if (is.na(probs[outcome_label])) {
      probs[outcome_label] <- 0
    }
  }

  if (!missing(custom)) {
    stopifnot(length(custom) == 5)
    probs['0'] <- custom[1]
    probs['1'] <- custom[2]
    probs['2'] <- custom[3]
    probs['3'] <- custom[4]
    probs['4'] <- custom[5]
  }
  message("Probabilities used for each label:")
  message(paste0(capture.output(probs), collapse = "\n"))

  predict_empirical <- Vectorize(function(outcome) {
    p <- probs[[as.character(outcome)]]
    sample(c(0, 1), size = 1, prob = c(1 - p, p))
  })

  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Simulate outcome using the empirical distribution
    if (length(ind) > 0) {
      accession_df$episode_prediction[ind] <- predict_empirical(accession_df$episode_outcome[ind])
      accession_df$by[ind] <- id
      accession_df$decided[ind] <- final_decision
    }
    accession_df
  }
}


#' A reader that does purely guessing based on a coin flip
#'
#' @param p A number; the probability of the coin flip.
#' @param id A character string; the name given to the reader.
random_reader <- function(p, id) {
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    # Update the original data.frame
    accession_df$episode_prediction[ind] <- sample(c(0, 1), length(ind), replace = TRUE, prob = c(1-p, p))
    accession_df$by[ind] <- id
    accession_df$decided[ind] <- final_decision

    accession_df
  }
}


#' Merge the results from two readers
#'
#' @description When two readers agree with each other, set the `decided` flag to TRUE.
#' Otherwise, set `decided` to FALSE and the episode prediction to be 1 or -1.
#' where 1 refers to when reader 1 indicates cancer, when -1 refers to when
#' reader 2 indicates cancer.
#'
#' @param reader_1_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_2_df A data frame; the data frame containing the reader's episode predictions.
#' @param ind A integer vector; the row numbers to be updated.
#' @param id A character string; the name given to the reader.
merge_two_readers <- function(reader_1_df, reader_2_df, ind, id) {
  if (missing(ind)) {
    ind <- which(reader_1_df$decided == FALSE)
  }
  merged_reader <- reader_1_df

  agree <- reader_1_df$episode_prediction[ind] == reader_2_df$episode_prediction[ind]
  merged_reader$by[ind] <- id
  merged_reader[ind, ][which(agree), ]$decided <- TRUE

  reader_1_reads <- reader_1_df[ind, ][which(!agree), ]$episode_prediction
  reader_2_reads <- reader_2_df[ind, ][which(!agree), ]$episode_prediction
  merged_reader[ind, ][which(!agree), ]$episode_prediction <- reader_1_reads - reader_2_reads
  merged_reader[ind, ][which(!agree), ]$decided <- FALSE

  merged_reader
}


# 2023-06-22 ===================================================================
#' A reader that uses the actual database when possible and simulates when not
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#' @param custom A numeric vector for the simulated reader, corresponding to the
#' probabilities of classifying the episodes as cancers when the labels are 0
#' (normal), 1 (screen-detected cancer), 2 (interval cancer), 3 (benign), 4 (no
#' significant abnormality). Examples include: c(0, 1, 0.2, 1, 1); c(0, 1, 0.25,
#' 1, 1), c(0, 1, 0.3, 1, 1) for unpooled labels, and c(0.446, 0.958, 0.958,
#' 0.446, 0.446) for pooled labels.
#'
#' @export
mixed_reader <- function(reader_df, reader_position, id, custom) {
  available_episodes <- reader_df |>
    filter(reader_number == reader_position) |>
    extract2("episode_id") |>
    unique()

  actual <- admani_reader(reader_df, reader_position, paste0(id, "(data)"))
  sim <- simulated_reader(reader_df, reader_position, paste0(id, "(sim)"), custom)
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    available_in_db <- accession_df$episode_id[ind] %in% available_episodes
    ind_available <- ind[available_in_db]
    ind_unavailable <- ind[!available_in_db]

    accession_df |>
      actual(ind_available, final_decision) |>
      sim(ind_unavailable, final_decision)
  }
}


#' A third reader that uses the early readers' read if the episodes are not available
#' at the third position.
#'
#' @param reader_df A data frame; the data frame containing the reader's episode predictions.
#' @param reader_position 1 or 2 only; the position of the reader in the 3-reader consensus model.
#' @param id A character string; the name given to the reader.
#'
#' @export
reader_n3 <- function(reader_df, reader_position, id) {
  stopifnot(reader_position == 1 || reader_position == 2)

  available_episodes <- reader_df |>
    filter(reader_number == 3) |>
    extract2("episode_id") |>
    unique()

  actual <- admani_reader(reader_df, 3, paste0(id, "(true)"))
  subst <- admani_reader(reader_df, reader_position, paste0(id, "(subst)"))
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    available_in_db <- accession_df$episode_id[ind] %in% available_episodes
    ind_available <- ind[available_in_db]
    ind_unavailable <- ind[!available_in_db]

    accession_df |>
      actual(ind_available, final_decision) |>
      subst(ind_unavailable, final_decision)
  }
}



# 2023-09-12 ===================================================================
#' A oracle "reader" that corrects some proportion of the predictions
#'
#' @param prop A number between 0 and 1; the proportion of labels to correct.
#'
#' @export
correction_reader <- function(prop) {
  function(accession_df, ind, final_decision = FALSE) {
    if (missing(ind)) {
      ind <- which(accession_df$decided == FALSE)
    }

    miss_ind <- intersect(ind, which(accession_df$episode_outcome != accession_df$episode_prediction))
    corr_ind <- sample(miss_ind, floor(length(miss_ind) * prop))

    if (length(corr_ind) > 0) {
      accession_df$episode_prediction[corr_ind] <- 1 - accession_df$episode_prediction[corr_ind]
    }
    accession_df
  }
}


# 2024-02-05 ===================================================================
#' A reader with access to AI decision (auditor)
#'
#' @description A reader with access to AI decision makes their own decision but
#'   have the opportunity to consider adjusting it if it disagrees with the AI's
#'   ones.
#'
#' @param reader_df A data frame; the data frame containing the reader's episode
#'   predictions.
#' @param reader_position 1,2 or 3; the position of the reader in the 3-reader
#'   consensus model.
#' @param id A character string; the name given to the reader.
#' @param model_df A data frame; the data frame containing the model episode
#'   predictions.
#' @param threshold A number between 0 and 1; the threshold above which the
#'   prediction score is classified as cancer.
#' @param scores A vector of model scores; if provided, it will be use for
#'   soft-merging.
#' @param probs A vector of 4 probabilities of whether soft-merging would
#'   happen, corresponding to the 4 cases in \link{reader_learning_from_ai}.
#' @param require_sim TRUE / FALSE; whether the human reader is simulated. This
#'   is needed when earlier reads are modified such that there is no
#'   corresponding third read record in the database.
#' @param ... Optional argument `custom` to pass to `simulated_reader`.
#'
#' @export
reader_auditing_ai <- function(reader_df, reader_position, id,
                               model_df, threshold, scores,
                               probs = c(1, 1, 0, 0),
                               require_sim = FALSE, ...) {
  if (require_sim) {
    human_reader <- simulated_reader(reader_df, reader_position, id, ...)
  } else {
    human_reader <- admani_reader(reader_df, reader_position, id)
  }
  ai_reader <- AI_reader(model_df, threshold, id)
  function(accession_df, ind, final_decision = FALSE) {
    human_reads <- human_reader(accession_df, ind, FALSE)
    ai_reads <- ai_reader(accession_df, ind, final_decision)
    sequential_soft_merge_two_readers(
      human_reads, ai_reads, ind, id, scores = scores,
      probs[1], probs[2], probs[3], probs[4]
    )
  }
}


#' A reader with access to AI decision (learner)
#'
#' @description A reader with access to AI decision make their own decision and
#'   it gets automatically corrected if the AI decision is correct assuming
#'   access to the ground truth. This models an ideal situation.
#'
#' @inheritParams reader_auditing_ai
#' @param p_agree_0 A number between 0 and 1; the probability of agreeing with
#'   AI, when human predicts normal and AI disagrees.
#' @param p_agree_1 A number between 0 and 1; the probability of agreeing with
#'   AI, when human predicts cancer and AI disagrees
#' @param p_disagree_0 A number between 0 and 1; the probability of disagreeing
#'   with AI, when human predicts normal and AI agrees.
#' @param p_disagree_1 A number between 0 and 1; the probability of disagreeing
#'   with AI, when human predicts cancer and AI agrees.
#'
#' @param method "correction" or "error"; what reader learns from AI
#'
#' @export
reader_learning_from_ai <- function(reader_df, reader_position, id, model_df, threshold,
                                    p_agree_0, p_agree_1, p_disagree_0, p_disagree_1,
                                    method = "correction",
                                    require_sim = FALSE, ...) {
  if (require_sim) {
    human_reader <- simulated_reader(reader_df, reader_position, id, ...)
  } else {
    human_reader <- admani_reader(reader_df, reader_position, id)
  }
  ai_reader <- AI_reader(model_df, threshold, id)
  function(accession_df, ind, final_decision = FALSE) {
    human_reads <- human_reader(accession_df, ind, FALSE)
    ai_reads <- ai_reader(accession_df, ind, final_decision)
    if (method == "correction") {
      return (corrective_merge_two_readers(
        human_reads, ai_reads, ind, id,
        p_agree_0, p_agree_1, p_disagree_0, p_disagree_1
      ))
    } else if (method == "error") {
      return(err_merge_two_readers(
        human_reads, ai_reads, ind, id,
        p_agree_0, p_agree_1, p_disagree_0, p_disagree_1
      ))
    } else {
      stop("Wrong input for argument 'method'; it must be 'correction' or 'error'.")
    }
  }
}


#' A simulated reader with access to AI decision
#'
#' @inheritParams simulated_reader
#' @inheritParams reader_learning_from_ai
#'
#' @export
simulated_reader_with_ai_interaction <- function(reader_df, reader_position, id,
                                                 model_df, threshold,
                                                 p_agree_0, p_agree_1, p_disagree_0, p_disagree_1,
                                                 ...) {
  sim_reader <- simulated_reader(reader_df, reader_position, id, ...)
  ai_reader <- AI_reader(model_df, threshold, id)
  function(accession_df, ind, final_decision = FALSE) {
    sim_human_reads <- sim_reader(accession_df, ind, FALSE)
    ai_reads <- ai_reader(accession_df, ind, final_decision)
    sequential_merge_two_readers(
      sim_human_reads, ai_reads, ind, id,
      p_agree_0, p_agree_1, p_disagree_0, p_disagree_1
    )
  }
}


#' Sequential merge of two readers
#'
#' @inheritParams merge_two_readers
#' @inheritParams reader_learning_from_ai
sequential_merge_two_readers <- function(reader_1_df, reader_2_df, ind, id,
                                         p_agree_0, p_agree_1, p_disagree_0, p_disagree_1) {
  # Helpers
  sample_bernoulli <- function(xs, p) {
    keep <- sample(c(F, T), length(xs), replace = TRUE, prob = c(1 - p, p))
    xs[keep]
  }

  # Main
  if (missing(ind)) {
    ind <- which(reader_1_df$decided == FALSE)
  }
  merged_reader <- reader_1_df  # The decided flag follows the first reader
  merged_reader$by[ind] <- id

  # Interaction between the two readers
  disagree <- reader_1_df$episode_prediction[ind] != reader_2_df$episode_prediction[ind]
  disagree_normal <- disagree & (reader_1_df$episode_prediction[ind] == 0)
  disagree_cancer <- disagree & (reader_1_df$episode_prediction[ind] == 1)

  agree <- reader_1_df$episode_prediction[ind] == reader_2_df$episode_prediction[ind]
  agree_normal <- agree & (reader_1_df$episode_prediction[ind] == 0)
  agree_cancer <- agree & (reader_1_df$episode_prediction[ind] == 1)

  # p_agree_0 refers to probability of converting into an agreement
  disagree_normal_index <- sample_bernoulli(which(disagree_normal), p_agree_0)
  disagree_cancer_index <- sample_bernoulli(which(disagree_cancer), p_agree_1)
  # p_disagree_0 refers to probability of converting into a disagreement (this models situation like algorithm aversion)
  agree_normal_index <- sample_bernoulli(which(agree_normal), p_disagree_0)
  agree_cancer_index <- sample_bernoulli(which(agree_cancer), p_disagree_1)

  overtune_index <- c(disagree_normal_index, disagree_cancer_index,
                      agree_normal_index, agree_cancer_index)
  merged_reader$episode_prediction[ind][overtune_index] <- 1 - merged_reader$episode_prediction[ind][overtune_index]
  merged_reader
}


#' Sequential soft-merge of two readers
#'
#' @inheritParams merge_two_readers
#' @inheritParams reader_learning_from_ai
#' @param scores A data frame of scores for soft merging; the episode id and the prediction scores.
sequential_soft_merge_two_readers <- function(reader_1_df, reader_2_df, ind, id, scores,
                                              p_agree_0 = 1, p_agree_1 = 1,
                                              p_disagree_0 = 0, p_disagree_1 = 0) {
  # Helpers
  sample_bernoulli <- function(xs, ps) {
    keep <- rbinom(length(xs), 1, ps) == 1
    xs[keep]
  }

  # Main
  if (missing(ind)) {
    ind <- which(reader_1_df$decided == FALSE)
  }
  merged_reader <- reader_1_df  # The decided flag follows the first reader
  merged_reader$by[ind] <- id

  # Interaction between the two readers
  disagree <- reader_1_df$episode_prediction[ind] != reader_2_df$episode_prediction[ind]
  disagree_normal <- disagree & reader_1_df$episode_prediction[ind] == 0
  disagree_cancer <- disagree & reader_1_df$episode_prediction[ind] == 1

  agree <- reader_1_df$episode_prediction[ind] == reader_2_df$episode_prediction[ind]
  agree_normal <- agree & (reader_1_df$episode_prediction[ind] == 0)
  agree_cancer <- agree & (reader_1_df$episode_prediction[ind] == 1)

  # p_agree_0 refers to probability of converting into an agreement
  scores_vec <- reader_1_df |>
    select(episode_id, by, decided) |>
    left_join(scores, by = 'episode_id') |>
    extract2("episode_prediction")

  disagree_normal_index <- sample_bernoulli(which(disagree_normal),
                                            p_agree_0 * scores_vec[ind][which(disagree_normal)])
  disagree_cancer_index <- sample_bernoulli(which(disagree_cancer),
                                            p_agree_1 * (1 - scores_vec[ind][which(disagree_cancer)]))
  # p_disagree_0 refers to probability of converting into a disagreement (this models situation like algorithm aversion)
  agree_normal_index <- sample_bernoulli(which(agree_normal),
                                         p_disagree_0 * scores_vec[ind][which(agree_normal)])
  agree_cancer_index <- sample_bernoulli(which(agree_cancer),
                                         p_disagree_1 * (1 - scores_vec[ind][which(agree_cancer)]))

  overtune_index <- c(disagree_normal_index, disagree_cancer_index,
                      agree_normal_index, agree_cancer_index)
  merged_reader$episode_prediction[ind][overtune_index] <- 1 - merged_reader$episode_prediction[ind][overtune_index]
  merged_reader$decided[ind] <- reader_2_df$decided[ind]
  merged_reader
}


#' Correct the first reader by the second reader (checking with respect to the ground truth)
#'
#' @inheritParams merge_two_readers
#' @inheritParams reader_learning_from_ai
corrective_merge_two_readers <- function(reader_1_df, reader_2_df, ind, id,
                                         p_agree_0, p_agree_1, p_disagree_0, p_disagree_1) {
  # Helpers
  sample_bernoulli <- function(xs, p) {
    keep <- sample(c(F, T), length(xs), replace = TRUE, prob = c(1 - p, p))
    xs[keep]
  }

  as_cancer <- \(x) x %in% c(1, 2)

  # Main
  if (missing(ind)) {
    ind <- which(reader_1_df$decided == FALSE)
  }
  merged_reader <- reader_1_df  # The decided flag follows the first reader
  merged_reader$by[ind] <- id

  # Interaction between the two readers
  disagree <- (reader_1_df$episode_prediction[ind] != reader_2_df$episode_prediction[ind]) &
    (reader_2_df$episode_prediction[ind] == 1.0 * as_cancer(reader_2_df$episode_outcome[ind]))
  disagree_normal <- disagree & (reader_1_df$episode_prediction[ind] == 0)
  disagree_cancer <- disagree & (reader_1_df$episode_prediction[ind] == 1)

  agree <- (reader_1_df$episode_prediction[ind] == reader_2_df$episode_prediction[ind]) &
    (reader_2_df$episode_prediction[ind] == 1.0 * as_cancer(reader_2_df$episode_outcome[ind]))
  agree_normal <- agree & (reader_1_df$episode_prediction[ind] == 0)
  agree_cancer <- agree & (reader_1_df$episode_prediction[ind] == 1)

  # p_agree_0 refers to probability of converting into an agreement
  disagree_normal_index <- sample_bernoulli(which(disagree_normal), p_agree_0)
  disagree_cancer_index <- sample_bernoulli(which(disagree_cancer), p_agree_1)
  # p_disagree_0 refers to probability of converting into a disagreement (this models situation like algorithm aversion)
  agree_normal_index <- sample_bernoulli(which(agree_normal), p_disagree_0)
  agree_cancer_index <- sample_bernoulli(which(agree_cancer), p_disagree_1)

  overtune_index <- c(disagree_normal_index, disagree_cancer_index,
                      agree_normal_index, agree_cancer_index)
  merged_reader$episode_prediction[ind][overtune_index] <- 1 - merged_reader$episode_prediction[ind][overtune_index]
  merged_reader$decided[ind] <- reader_2_df$decided[ind]
  merged_reader
}


#' Err the first reader by the second reader (checking with respect to the ground truth)
#'
#' @inheritParams merge_two_readers
#' @inheritParams reader_learning_from_ai
err_merge_two_readers <- function(reader_1_df, reader_2_df, ind, id,
                                  p_agree_0, p_agree_1, p_disagree_0, p_disagree_1) {
  # Helpers
  sample_bernoulli <- function(xs, p) {
    keep <- sample(c(F, T), length(xs), replace = TRUE, prob = c(1 - p, p))
    xs[keep]
  }

  as_cancer <- \(x) x %in% c(1, 2)

  # Main
  if (missing(ind)) {
    ind <- which(reader_1_df$decided == FALSE)
  }
  merged_reader <- reader_1_df  # The decided flag follows the first reader
  merged_reader$by[ind] <- id

  # Interaction between the two readers
  disagree <- (reader_1_df$episode_prediction[ind] != reader_2_df$episode_prediction[ind]) &
    (reader_2_df$episode_prediction[ind] != 1.0 * as_cancer(reader_2_df$episode_outcome[ind]))
  disagree_normal <- disagree & (reader_1_df$episode_prediction[ind] == 0)
  disagree_cancer <- disagree & (reader_1_df$episode_prediction[ind] == 1)

  agree <- (reader_1_df$episode_prediction[ind] == reader_2_df$episode_prediction[ind]) &
    (reader_2_df$episode_prediction[ind] != 1.0 * as_cancer(reader_2_df$episode_outcome[ind]))
  agree_normal <- agree & (reader_1_df$episode_prediction[ind] == 0)
  agree_cancer <- agree & (reader_1_df$episode_prediction[ind] == 1)

  # p_agree_0 refers to probability of converting into an agreement
  disagree_normal_index <- sample_bernoulli(which(disagree_normal), p_agree_0)
  disagree_cancer_index <- sample_bernoulli(which(disagree_cancer), p_agree_1)
  # p_disagree_0 refers to probability of converting into a disagreement (this models situation like algorithm aversion)
  agree_normal_index <- sample_bernoulli(which(agree_normal), p_disagree_0)
  agree_cancer_index <- sample_bernoulli(which(agree_cancer), p_disagree_1)

  overtune_index <- c(disagree_normal_index, disagree_cancer_index,
                      agree_normal_index, agree_cancer_index)
  merged_reader$episode_prediction[ind][overtune_index] <- 1 - merged_reader$episode_prediction[ind][overtune_index]
  merged_reader
}
