#' Baseline scenario
#'
#' @description The scenario corresponding to the existing screening pathway.
#' The three readers classify the episodes based on the "individual_recall"
#' column from the database.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#'
#' @return A data frame; the result of the scenario simulation.
#'
#' @export
baseline <- function(accession_df, reader_df) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)
}


#' Summary of a scenario
#'
#' @param res A data frame; the output from the scenario simulation.
#'
#' @return A list; the summary of the scenario.
#'
#' @export
scenario_summary <- function(res) {
  # Recall / no recall summary
  summary <- res |>
    group_by(episode_prediction, by) |>
    summarise(count = n())

  # Recall / no recall summary by sub-categories
  summary_by_outcome <- res |>
    group_by(episode_prediction, by, episode_outcome) |>
    summarise(count = n())

  # System performance
  performance <- confusion_matrix(res)

  list(result = res,
       summary = summary,
       summary_by_outcome = summary_by_outcome,
       performance = performance,
       extra = attr(res, "extra"))
}


# 2024-02-05 ===================================================================
# AI MASAI / Triage ----
# #' Human-AI interaction with the MASAI (triage) simulation
# #'
# #' @inheritParams AI_baseline_check
# #' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_with_ai_interaction}.
# #'
# #' @return A data frame; the result of the scenario simulation.
# #' @export
# AI_masai_interaction <- function(accession_df, reader_df, model_pred, threshold, probs) {
#   ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
#   reader_1 <- admani_reader(reader_df, 1, "reader-1")
#   reader_2 <- admani_reader(reader_df, 2, "reader-2")
#   reader_3 <- admani_reader(reader_df, 3, "reader-3")
#   # One-reader pathway (Need both reader 1 and 2 for randomisation)
#   reader_1b <- reader_with_ai_interaction(
#     reader_df, 1, "reader-1b", model_pred, threshold,
#     probs[1], probs[2], probs[3], probs[4]
#   )
#   reader_2b <- reader_with_ai_interaction(
#     reader_df, 2, "reader-2b", model_pred, threshold,
#     probs[1], probs[2], probs[3], probs[4]
#   )
#
#   first_pass <- ai_reader(accession_df)
#   first_pass_double <- first_pass |> filter(episode_prediction == 1)
#   first_pass_single <- first_pass |> filter(episode_prediction == 0)
#
#   double_read <- reader_1(first_pass_double) |>
#     merge_two_readers(reader_2(first_pass_double), id = "reader-1-and-2") |>
#     reader_3(final_decision = TRUE)
#
#   from_reader_1 <- sample(c(T, F), nrow(first_pass_single), replace = TRUE)
#   single_reader_1 <- reader_1b(first_pass_single, final_decision = TRUE)
#   single_reader_2 <- reader_2b(first_pass_single, final_decision = TRUE)
#   single_read <- rbind(single_reader_1[from_reader_1, ],
#                        single_reader_2[!from_reader_1, ])
#   rbind(single_read, double_read)
# }


#' Human-AI interaction with the MASAI (triage) simulation template
#'
#' @param ai_reader A function; the AI reader.
#' @param reader_1 A function; the first reader.
#' @param reader_2 A function; the second reader.
#' @param reader_3 A function; the third reader.
#' @param reader_1b A function; the first reader for the one-reader pathway.
#' @param reader_2b A function; the second reader for the one-reader pathway.
#'
#' @export
AI_masai_template <- function(ai_reader,
                              reader_1, reader_2, reader_3,  # Two-reader pathway
                              reader_1b, reader_2b) {        # One-reader pathway (Need both reader 1 and 2 for randomisation)
  function(accession_df) {
    first_pass <- ai_reader(accession_df)
    first_pass_double <- first_pass |> filter(episode_prediction == 1)
    first_pass_single <- first_pass |> filter(episode_prediction == 0)

    double_read <- reader_1(first_pass_double) |>
      merge_two_readers(reader_2(first_pass_double), id = "reader-1-and-2") |>
      reader_3(final_decision = TRUE)

    from_reader_1 <- sample(c(T, F), nrow(first_pass_single), replace = TRUE)
    single_reader_1 <- reader_1b(first_pass_single, final_decision = TRUE)
    single_reader_2 <- reader_2b(first_pass_single, final_decision = TRUE)
    single_read <- rbind(single_reader_1[from_reader_1, ],
                         single_reader_2[!from_reader_1, ])
    rbind(single_read, double_read)
  }
}


# Learn from AI
#' Human-AI interaction with the MASAI (triage) simulation
#'
#' @description
#' Only the reader on the single-reader pathway learns from AI.
#'
#' @inheritParams AI_baseline_check
#' @param model_tdf_branch A data frame; the data frame containing the
#'   thresholded model prediction. The threshold should be responsible for
#'   deciding the branching in the Triage scenario.
#' @param model_tdf_flip A data frame; the data frame containing the thresholded
#'   model prediction. The threshold is the operating point of the AI to be
#'   learned from.
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#' @param method "correction" or "error".
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai_learn_from_AI <- function(accession_df, reader_df, model_tdf_branch, model_tdf_flip, probs, method) {
  dummy_threshold <- 0.5
  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf_branch, dummy_threshold, "ai-reader"),
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3"),
    reader_1b = reader_learning_from_ai(
      reader_df, 1, "reader-1b", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2b = reader_learning_from_ai(
      reader_df, 2, "reader-2b", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    )
  )
  f(accession_df)
}


#' Human-AI interaction with the MASAI (triage) simulation
#'
#' @description
#' Reader 1 and 2 on all paths learns from AI. Reader 3 uses the real data.
#'
#' @inheritParams AI_masai_learn_from_AI
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai_learn_from_AI_all_paths <- function(accession_df, reader_df, model_tdf_branch, model_tdf_flip, probs, method) {
  dummy_threshold <- 0.5
  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf_branch, dummy_threshold, "ai-reader"),
    reader_1 = reader_learning_from_ai(
      reader_df, 1, "reader-1", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2 = reader_learning_from_ai(
      reader_df, 2, "reader-2", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_3 = admani_reader(reader_df, 3, "reader-3"),
    reader_1b = reader_learning_from_ai(
      reader_df, 1, "reader-1b", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2b = reader_learning_from_ai(
      reader_df, 2, "reader-2b", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    )
  )
  f(accession_df)
}


#' Human-AI interaction with the MASAI (triage) simulation
#'
#' @description
#' All readers learn from AI on all paths.
#'
#' @inheritParams AI_masai_learn_from_AI
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#' @param require_sim TRUE or FALSE; whether to require simulation for the third reader.
#' @param ... Additional arguments to be passed to the simulated reader.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai_learn_from_AI_all_readers <- function(accession_df, reader_df, model_tdf_branch, model_tdf_flip, probs, method,
                                               require_sim = FALSE, ...) {
  dummy_threshold <- 0.5
  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf_branch, dummy_threshold, "ai-reader"),
    reader_1 = reader_learning_from_ai(
      reader_df, 1, "reader-1", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2 = reader_learning_from_ai(
      reader_df, 2, "reader-2", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_3 = reader_learning_from_ai(
      reader_df, 3, "reader-3", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method,
      require_sim, ...
    ),
    reader_1b = reader_learning_from_ai(
      reader_df, 1, "reader-1b", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2b = reader_learning_from_ai(
      reader_df, 2, "reader-2b", model_tdf_flip, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    )
  )
  f(accession_df)
}


# Audit AI
#' Human-AI interaction with the MASAI (triage) simulation
#'
#' @description
#' Only the reader in the single-reader path uses (audits) AI output.
#'
#' @inheritParams AI_masai_learn_from_AI
#' @param scores The model prediction scores. A data frame containing the episode id and the prediction scores.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai_audit_AI <- function(accession_df, reader_df, model_tdf_branch, model_tdf_flip, scores) {
  dummy_threshold <- 0.5
  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf_branch, dummy_threshold, "ai-reader"),
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3"),
    reader_1b = reader_auditing_ai(
      reader_df, 1, "reader-1b", model_tdf_flip, dummy_threshold, scores
    ),
    reader_2b = reader_auditing_ai(
      reader_df, 2, "reader-2b", model_tdf_flip, dummy_threshold, scores
    )
  )
  f(accession_df)
}


#' Human-AI interaction with the MASAI (triage) simulation
#'
#' @description
#' Reader 1 / 2 on all paths use (audit) AI output.
#'
#' @inheritParams AI_masai_learn_from_AI
#' @param scores The model prediction scores. A data frame containing the episode id and the prediction scores.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai_audit_AI_all_paths <- function(accession_df, reader_df, model_tdf_branch, model_tdf_flip, scores, custom) {
  dummy_threshold <- 0.5
  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf_branch, dummy_threshold, "ai-reader"),
    reader_1 = reader_auditing_ai(reader_df, 1, "reader-1", model_tdf_flip, dummy_threshold, scores),
    reader_2 = reader_auditing_ai(reader_df, 2, "reader-2", model_tdf_flip, dummy_threshold, scores),
    reader_3 = simulated_reader(reader_df, 3, "reader-3", custom),
    reader_1b = reader_auditing_ai(reader_df, 1, "reader-1b", model_tdf_flip, dummy_threshold, scores),
    reader_2b = reader_auditing_ai(reader_df, 2, "reader-2b", model_tdf_flip, dummy_threshold, scores)
  )
  f(accession_df)
}


#' Human-AI interaction with the MASAI (triage) simulation
#'
#' @description
#' All readers use (audit) AI output.
#'
#' @inheritParams AI_masai_learn_from_AI
#' @param scores The model prediction scores. A data frame containing the episode id and the prediction scores.
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_auditing_ai}.
#' @param require_sim TRUE or FALSE; whether to require simulation for the third reader.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai_audit_AI_all_readers <- function(accession_df, reader_df, model_tdf_branch, model_tdf_flip, scores,
                                          probs = c(1, 1, 0, 0), require_sim, custom) {
  dummy_threshold <- 0.5
  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf_branch, dummy_threshold, "ai-reader"),
    reader_1 = reader_auditing_ai(reader_df, 1, "reader-1", model_tdf_flip, dummy_threshold, scores, probs = probs),
    reader_2 = reader_auditing_ai(reader_df, 2, "reader-2", model_tdf_flip, dummy_threshold, scores, probs = probs),
    reader_3 = reader_auditing_ai(reader_df, 3, "reader-3", model_tdf_flip, dummy_threshold, scores, probs = probs,
                                  require_sim = require_sim, custom = custom),
    reader_1b = reader_auditing_ai(reader_df, 1, "reader-1b", model_tdf_flip, dummy_threshold, scores, probs = probs),
    reader_2b = reader_auditing_ai(reader_df, 2, "reader-2b", model_tdf_flip, dummy_threshold, scores, probs = probs)
  )
  f(accession_df)
}



# Band pass ====
#' Human-AI interaction with the band-pass simulation template
#' @param low_band_reader A function; the AI reader for the low band. Episodes with scores below the threshold are sent to direct no recall.
#' @param high_band_reader A function; the AI reader for the high band. Episodes with scores above the threshold are sent to direct recall.
#' @param reader_1 A function; the first reader.
#' @param reader_2 A function; the second reader.
#' @param reader_3 A function; the third reader.
#' @export
AI_band_pass_template <- function(low_band_reader, high_band_reader, reader_1, reader_2, reader_3) {
  function(accession_df) {
    first_pass <- low_band_reader(accession_df)
    first_pass_recall <- first_pass |> filter(episode_prediction == 1)
    first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
    first_pass_no_recall$decided <- TRUE

    second_pass <- high_band_reader(first_pass_recall)
    second_pass_recall <- second_pass |> filter(episode_prediction == 1)
    second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
    second_pass_recall$decided <- TRUE

    pass_read <- reader_1(second_pass_no_recall) |>
      merge_two_readers(reader_2(second_pass_no_recall), id = "reader-1-and-2") |>
      reader_3(final_decision = TRUE)

    rbind(first_pass_no_recall, second_pass_recall, pass_read)
  }
}


#' Human-AI interaction with the band-pass simulation
#' @description Reader 1 and 2 use (audit) AI output.
#' @inheritParams AI_baseline_check
#' @param model_l_tdf A data frame; the data frame containing the thresholded model prediction for the low band.
#' @param model_u_tdf A data frame; the data frame containing the thresholded model prediction for the high band.
#' @param model_q_tdf A data frame; the data frame containing the thresholded model prediction for the third reader.
#' @param scores The model prediction scores. A data frame containing the thresholded
#'   model prediction. The threshold is the operating point of the AI to be learned from.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#' @export
AI_band_pass_audit <- function(accession_df, reader_df, model_l_tdf, model_u_tdf, model_q_tdf, scores, custom) {
  dummy_threshold <- 0.5
  f <- AI_band_pass_template(
    low_band_reader = AI_reader(model_l_tdf, dummy_threshold, "AI-reader"),
    high_band_reader = AI_reader(model_u_tdf, dummy_threshold, "AI-reader"),
    reader_1 = reader_auditing_ai(reader_df, 1, "reader-1", model_q_tdf, dummy_threshold, scores),
    reader_2 = reader_auditing_ai(reader_df, 2, "reader-2", model_q_tdf, dummy_threshold, scores),
    reader_3 = simulated_reader(reader_df, 3, "reader-3", custom)
  )
  f(accession_df)
}


#' Human-AI interaction with the band-pass simulation
#' @description All readers use (audit) AI output.
#' @inheritParams AI_band_pass_audit
#' @inheritParams reader_auditing_ai
#' @export
AI_band_pass_audit_all_readers <- function(accession_df, reader_df, model_l_tdf, model_u_tdf, model_q_tdf,
                                           scores, probs, require_sim, custom) {
  dummy_threshold <- 0.5
  f <- AI_band_pass_template(
    low_band_reader = AI_reader(model_l_tdf, dummy_threshold, "AI-reader"),
    high_band_reader = AI_reader(model_u_tdf, dummy_threshold, "AI-reader"),
    reader_1 = reader_auditing_ai(reader_df, 1, "reader-1", model_q_tdf, dummy_threshold, scores, probs = probs),
    reader_2 = reader_auditing_ai(reader_df, 2, "reader-2", model_q_tdf, dummy_threshold, scores, probs = probs),
    reader_3 = reader_auditing_ai(reader_df, 3, "reader-3", model_q_tdf, dummy_threshold, scores, probs = probs,
                                  require_sim = require_sim, custom = custom)
  )
  f(accession_df)
}


#' Human-AI interaction with the band-pass simulation
#' @description Reader 1 and 2 learn from AI output.
#' @inheritParams AI_band_pass_audit
#' @inheritParams reader_learning_from_ai
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#' @export
AI_band_pass_learn <- function(accession_df, reader_df, model_l_tdf, model_u_tdf, model_q_tdf,
                               probs, method) {
  dummy_threshold <- 0.5
  f <- AI_band_pass_template(
    low_band_reader = AI_reader(model_l_tdf, dummy_threshold, "AI-reader"),
    high_band_reader = AI_reader(model_u_tdf, dummy_threshold, "AI-reader"),
    reader_1 = reader_learning_from_ai(
      reader_df, 1, "reader-1", model_q_tdf, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2 = reader_learning_from_ai(
      reader_df, 2, "reader-2", model_q_tdf, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_3 = admani_reader(reader_df, 3, "reader-3")
  )
  f(accession_df)
}


#' Human-AI interaction with the band-pass simulation
#' @description All readers learn from AI output.
#' @inheritParams AI_band_pass_audit
#' @inheritParams reader_learning_from_ai
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#' @export
AI_band_pass_learn_all_readers <- function(accession_df, reader_df, model_l_tdf, model_u_tdf, model_q_tdf,
                                           probs, method, require_sim, custom) {
  dummy_threshold <- 0.5
  f <- AI_band_pass_template(
    low_band_reader = AI_reader(model_l_tdf, dummy_threshold, "AI-reader"),
    high_band_reader = AI_reader(model_u_tdf, dummy_threshold, "AI-reader"),
    reader_1 = reader_learning_from_ai(
      reader_df, 1, "reader-1", model_q_tdf, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_2 = reader_learning_from_ai(
      reader_df, 2, "reader-2", model_q_tdf, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method
    ),
    reader_3 = reader_learning_from_ai(
      reader_df, 3, "reader-3", model_q_tdf, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method,
      require_sim = require_sim, custom = custom
    )
  )
  f(accession_df)
}


# AI independent reading ----
#' AI independent reading
#'
#' @description This scenario replaces the second reader with the AI reader.
#' The third reads are simulated based on the empirical performance of the
#' third reader and to be influenced by AI.
#'
#' @inheritParams AI_baseline_check
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{simulated_reader_with_ai_interaction}.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_interaction <- function(accession_df, reader_df,
                                       model_pred, threshold, probs, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")  # for randomisation
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader-2")
  reader_3pAI <- simulated_reader_with_ai_interaction(
    reader_df, 3, "reader-3pAI",
    model_pred, threshold,
    probs[1], probs[2], probs[3], probs[4],
    ... # custom (optional) for simulated reader
  )

  from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)
  extract <- `[`

  accession_df_grp_1 <- reader_1(accession_df) |>
    merge_two_readers(ai_reader(accession_df), id = "reader-1-and-AI") |>
    reader_3pAI(final_decision = TRUE) |
    extract(from_reader_1, )

  accession_df_grp_2 <- reader_2(accession_df) |>
    merge_two_readers(ai_reader(accession_df), id = "reader-1-and-AI") |>
    reader_3pAI(final_decision = TRUE) |>
    extract(!from_reader_1, )

  rbind(accession_df_grp_1, accession_df_grp_2)
}


#' AI independent simulation template
#' @param reader_1 A function; the first reader.
#' @param reader_2 A function; the second reader.
#' @param ai_reader A function; the AI reader.
#' @param reader_3 A function; the third reader.
AI_independent_template <- function(reader_1, reader_2, ai_reader, reader_3) {
  function(accession_df) {
    from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)

    accession_df_grp_1 <- merge_two_readers(
      reader_1(accession_df),
      ai_reader(accession_df),
      id = "reader-1-and-AI"
    )[from_reader_1, ]

    accession_df_grp_2 <- merge_two_readers(
      reader_2(accession_df),
      ai_reader(accession_df),
      id = "reader-2-and-AI"
    )[!from_reader_1, ]

    rbind(accession_df_grp_1, accession_df_grp_2) |>
      reader_3(final_decision = TRUE)
  }
}


#' AI independent simulation (audit)
#' @description Only reader 3 uses / audits the AI output.
#' @inheritParams AI_baseline_check
#' @inheritParams reader_auditing_ai
#' @param model_tdf A data frame; the data frame containing the thresholded model prediction.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#' @export
AI_independent_audit <- function(accession_df, reader_df, model_tdf, scores, probs, custom) {
  dummy_threshold <- 0.5
  f <- AI_independent_template(
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    ai_reader = AI_reader(model_tdf, dummy_threshold, "AI-reader"),
    reader_3 = reader_auditing_ai(reader_df, 3, "reader-3", model_tdf, dummy_threshold, scores,
                                  probs = probs, require_sim = TRUE, custom = custom)
  )
  f(accession_df)
}


#' AI independent simulation (learn)
#' @description Only reader 3 learns from the AI output.
#' @inheritParams AI_baseline_check
#' @inheritParams reader_learning_from_ai
#' @param model_tdf A data frame; the data frame containing the thresholded model prediction.
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#' @export
AI_independent_learn <- function(accession_df, reader_df, model_tdf, probs, method, custom) {
  dummy_threshold <- 0.5
  f <- AI_independent_template(
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    ai_reader = AI_reader(model_tdf, dummy_threshold, "AI-reader"),
    reader_3 = reader_learning_from_ai(
      reader_df, 3, "reader-3", model_tdf, dummy_threshold,
      probs[1], probs[2], probs[3], probs[4], method = method,
      require_sim = TRUE, custom = custom
    )
  )
  f(accession_df)
}




# Risk analysis ----------------------------------------------------------------
# Model when the AI reader is fully compromised
#' AI triage scenario with dummy AI readers
#' @description This models when the AI (triage) reader is compromised.
#' @inheritParams AI_baseline_check
#' @param p The proportion of the model predictions to be assigned a random outcome from the Bernoulli distribution.
#' @export
AI_masai_risk <- function(accession_df, reader_df, p) {
  f <- AI_masai_template(
    ai_reader = random_reader(p, "ai-reader"),
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3"),
    reader_1b = admani_reader(reader_df, 1, "reader-1b"),
    reader_2b = admani_reader(reader_df, 2, "reader-2b")
  )
  f(accession_df)
}


#' AI band-pass scenario with dummy AI readers
#' @description This models when both low-band and high-band AI readers are compromised.
#' @inheritParams AI_baseline_check
#' @param model_df A data frame; the data frame containing the model predictions.
#' @export
AI_band_pass_risk <- function(accession_df, reader_df, model_df, threshold) {
  stopifnot(length(threshold) == 2)
  model_df$episode_prediction <- runif(length(model_df$episode_prediction))

  low_band_reader <- AI_reader(model_df, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_df, threshold[2], "AI-reader")
  f <- AI_band_pass_template(
    low_band_reader = low_band_reader,
    high_band_reader = high_band_reader,
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3")
  )
  f(accession_df)
}


#' AI independent scenario with dummy AI readers
#' @description This models when the AI (replacement) reader is compromised.
#' @inheritParams AI_baseline_check
#' @param p The proportion of the model predictions to be assigned a random outcome from the Bernoulli distribution.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#' @export
AI_independent_risk <- function(accession_df, reader_df, p, custom) {
  f <- AI_independent_template(
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    ai_reader = random_reader(p, "ai-reader"),
    reader_3 = simulated_reader(reader_df, 3, "sim-reader-3", custom)
  )
  f(accession_df)
}


# Model distributional drift
#' AI triage scenario with drift
#' @description This models when the AI (triage) reader performs under distributional drift.
#' @inheritParams AI_baseline_check
#' @param model_df A data frame; the data frame containing the model predictions.
#' @param q_threshold The quantile of the model prediction to be used as the threshold.
#' @param p The proportion of the model predictions to be assigned a random score from the uniform distribution.
#' @export
AI_masai_drift <- function(accession_df, reader_df, model_df, q_threshold, p) {
  n <- nrow(model_df)
  corrupt_ind <- sample(n, floor(p * n))
  model_df$episode_prediction[corrupt_ind] <- runif(length(corrupt_ind), 0, 1)

  model_tdf <- model_df |> apply_manufacturer_quantile_threshold(q_threshold)
  dummy_threshold <- 0.5

  f <- AI_masai_template(
    ai_reader = AI_reader(model_tdf, dummy_threshold, "ai-reader"),
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3"),
    reader_1b = admani_reader(reader_df, 1, "reader-1b"),
    reader_2b = admani_reader(reader_df, 2, "reader-2b")
  )
  f(accession_df)
}


#' AI band-pass scenario with drift
#' @description This models when both AI (band-pass) readers perform under distributional drift.
#' @inheritParams AI_baseline_check
#' @param model_df A data frame; the data frame containing the model predictions.
#' @param q_threshold A vector of 2 numbers; the quantiles of the model prediction to be used as the thresholds for the low-band reader and the high-band reader.
#' @param p The proportion of the model predictions to be assigned a random score from the uniform distribution.
#' @export
AI_band_pass_drift_quantile_threshold <- function(accession_df, reader_df, model_df, q_threshold, p) {
  stopifnot(length(q_threshold) == 2)

  n <- nrow(model_df)
  corrupt_ind <- sample(n, floor(p * n))
  model_df$episode_prediction[corrupt_ind] <- runif(length(corrupt_ind), 0, 1)

  model_tdf_l <- model_df |> apply_manufacturer_quantile_threshold(q_threshold[1])
  model_tdf_u <- model_df |> apply_manufacturer_quantile_threshold(q_threshold[2])
  dummy_threshold <- 0.5

  low_band_reader <- AI_reader(model_tdf_l, dummy_threshold, "AI-reader")
  high_band_reader <- AI_reader(model_tdf_u, dummy_threshold, "AI-reader")
  f <- AI_band_pass_template(
    low_band_reader = low_band_reader,
    high_band_reader = high_band_reader,
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3")
  )
  f(accession_df)
}


#' AI band-pass scenario with drift
#' @description This models when both AI (band-pass) readers perform under distributional drift.
#' @inheritParams AI_baseline_check
#' @param model_df A data frame; the data frame containing the model predictions.
#' @param threshold_l The (manufacturer specific) threshold for the low-band reader.
#' @param threshold_u The (manufacturer specific) threshold for the high-band reader.
#' @param p The proportion of the model predictions to be assigned a random score from the uniform distribution.
#' @export
AI_band_pass_drift <- function(accession_df, reader_df, model_df, threshold_l, threshold_u, p) {
  n <- nrow(model_df)
  corrupt_ind <- sample(n, floor(p * n))
  model_df$episode_prediction[corrupt_ind] <- runif(length(corrupt_ind), 0, 1)

  model_tdf_l <- model_df |> apply_manufacturer_threshold(threshold_l)
  model_tdf_u <- model_df |> apply_manufacturer_threshold(threshold_u)
  dummy_threshold <- 0.5

  low_band_reader <- AI_reader(model_tdf_l, dummy_threshold, "AI-reader")
  high_band_reader <- AI_reader(model_tdf_u, dummy_threshold, "AI-reader")
  f <- AI_band_pass_template(
    low_band_reader = low_band_reader,
    high_band_reader = high_band_reader,
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    reader_3 = admani_reader(reader_df, 3, "reader-3")
  )
  f(accession_df)
}


#' AI independent scenario with drift
#' @description This models when the AI (replacement) reader performs under distributional drift.
#' @inheritParams AI_baseline_check
#' @param model_df A data frame; the data frame containing the model predictions.
#' @param q_threshold The quantile of the model prediction to be used as the threshold.
#' @param p The proportion of the model predictions to be assigned a random score from the uniform distribution.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#' @export
AI_independent_drift_quantile_threshold <- function(accession_df, reader_df, model_df, q_threshold, p, custom) {
  n <- nrow(model_df)
  corrupt_ind <- sample(n, floor(p * n))
  model_df$episode_prediction[corrupt_ind] <- runif(length(corrupt_ind), 0, 1)

  model_tdf <- model_df |> apply_manufacturer_quantile_threshold(q_threshold)
  dummy_threshold <- 0.5

  f <- AI_independent_template(
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    ai_reader = AI_reader(model_tdf, dummy_threshold, "ai-reader"),
    reader_3 = simulated_reader(reader_df, 3, "sim-reader-3", custom)
  )
  f(accession_df)
}


#' AI independent scenario with drift
#' @description This models when the AI (replacement) reader performs under distributional drift.
#' @inheritParams AI_baseline_check
#' @param model_df A data frame; the data frame containing the model predictions.
#' @param p The proportion of the model predictions to be assigned a random score from the uniform distribution.
#' @param custom A vector; the custom parameters for the simulated reader. See \link{simulated_reader}.
#' @export
AI_independent_drift <- function(accession_df, reader_df, model_df, threshold, p, custom) {
  n <- nrow(model_df)
  corrupt_ind <- sample(n, floor(p * n))
  model_df$episode_prediction[corrupt_ind] <- runif(length(corrupt_ind), 0, 1)

  model_tdf <- model_df |> apply_manufacturer_threshold(threshold)
  dummy_threshold <- 0.5

  f <- AI_independent_template(
    reader_1 = admani_reader(reader_df, 1, "reader-1"),
    reader_2 = admani_reader(reader_df, 2, "reader-2"),
    ai_reader = AI_reader(model_tdf, dummy_threshold, "ai-reader"),
    reader_3 = simulated_reader(reader_df, 3, "sim-reader-3", custom)
  )
  f(accession_df)
}




# Single reader and Sequential reader scenario ----
#' Sequential reader scenario
#' @description This models the scenario with two readers. The first reader is
#' a human reader and the second reader is the AI reader.
#' @inheritParams AI_baseline_check
#' @param model_tdf A data frame; the data frame containing the thresholded model predictions.
#' @param p_recall probability to recall when disagreement occurs. Use 1 to
#'   recall if any of the readers decides to recall, and 0 to recall if all of
#'   the readers decide to recall (i.e., no recall when there is disagreement).
AI_sequential <- function(accession_df, reader_df, model_tdf, p_recall) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  dummy_threshold <- 0.5
  ai_reader <- AI_reader(model_tdf, dummy_threshold, "ai-reader")

  f <- function(accession_df) {
    from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)

    accession_df_grp_1 <- merge_two_readers(
      reader_1(accession_df),
      ai_reader(accession_df),
      id = "reader-1-and-AI"
    )[from_reader_1, ]

    accession_df_grp_2 <- merge_two_readers(
      reader_2(accession_df),
      ai_reader(accession_df),
      id = "reader-2-and-AI"
    )[!from_reader_1, ]

    result <- rbind(accession_df_grp_1, accession_df_grp_2)
    undecided <- which(result$decided == FALSE)
    recall <- rbinom(length(undecided), 1, p_recall) == 1
    result$episode_prediction[undecided[recall]] <- 1
    result$episode_prediction[undecided[!recall]] <- 0
    result$decided <- TRUE
    result
  }
  f(accession_df)
}


#' Single ADMANI reader
#' @description This models the scenario with only one reader.
#' Note that this function does NOT use the AI reader. It serves as a baseline
#' for comparison with the AI reader.
#' @inheritParams AI_sequential
#' @export
AI_single <- function(accession_df, reader_df) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  f <- function(accession_df) {
    from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)
    accession_df_grp_1 <- reader_1(accession_df)[from_reader_1, ]
    accession_df_grp_2 <- reader_2(accession_df)[!from_reader_1, ]
    result <- rbind(accession_df_grp_1, accession_df_grp_2)
    result$decided <- TRUE
    result
  }
  f(accession_df)
}


#' Single reader learning from AI
#' @description The sole reader learns from the AI output.
#' @inheritParams AI_sequential
#' @inheritParams reader_learning_from_ai
#' @param probs A vector of 4 probabilities; corresponding to the ones in \link{reader_learning_from_ai}.
#' @export
AI_single_learn <- function(accession_df, reader_df, model_tdf, probs, method, ...) {
  reader_1 <- reader_learning_from_ai(reader_df, 1, 'reader-1', model_tdf, threshold = 0.5,
                                      probs[1], probs[2], probs[3], probs[4],
                                      method = method, ...)
  reader_2 <- reader_learning_from_ai(reader_df, 2, 'reader-2', model_tdf, threshold = 0.5,
                                      probs[1], probs[2], probs[3], probs[4],
                                      method = method, ...)
  f <- function(accession_df) {
    from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)
    accession_df_grp_1 <- reader_1(accession_df)[from_reader_1, ]
    accession_df_grp_2 <- reader_2(accession_df)[!from_reader_1, ]
    result <- rbind(accession_df_grp_1, accession_df_grp_2)
    result$decided <- TRUE
    result
  }
  f(accession_df)
}

#' Single reader auditing output from AI
#' @description The sole reader audits the AI output.
#' @inheritParams AI_sequential
#' @inheritParams reader_auditing_ai
#' @export
AI_single_audit <- function(accession_df, reader_df, model_tdf, scores, probs, ...) {
  reader_1 <- reader_auditing_ai(reader_df, 1, 'reader-1', model_tdf, threshold = 0.5,
                                 scores, probs, ...)
  reader_2 <- reader_auditing_ai(reader_df, 2, 'reader-2', model_tdf, threshold = 0.5,
                                 scores, probs, ...)
  f <- function(accession_df) {
    from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)
    accession_df_grp_1 <- reader_1(accession_df)[from_reader_1, ]
    accession_df_grp_2 <- reader_2(accession_df)[!from_reader_1, ]
    result <- rbind(accession_df_grp_1, accession_df_grp_2)
    result$decided <- TRUE
    result
  }
  f(accession_df)
}




# 2023-09-05 ===================================================================
#' MASAI simulation
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_masai <- function(accession_df, reader_df, model_pred, threshold) {
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  first_pass <- ai_reader(accession_df)
  first_pass_double <- first_pass |> filter(episode_prediction == 1)
  first_pass_single <- first_pass |> filter(episode_prediction == 0)

  double_read <- reader_1(first_pass_double) |>
    merge_two_readers(reader_2(first_pass_double), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)

  from_reader_1 <- sample(c(T, F), nrow(first_pass_single), replace = TRUE)
  single_reader_1 <- reader_1(first_pass_single, final_decision = TRUE)
  single_reader_2 <- reader_2(first_pass_single, final_decision = TRUE)
  single_read <- rbind(single_reader_1[from_reader_1, ],
                       single_reader_2[!from_reader_1, ])
  rbind(single_read, double_read)
}


# 2023-06-22 ===================================================================
#' AI replacement with second reader as third reader when the episodes are not available
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_random_second_reader_arbiter <- function(accession_df, reader_df, model_pred, threshold, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
  reader_13 <- reader_n3(reader_df, 1, "mixed-reader-13")
  reader_23 <- reader_n3(reader_df, 2, "mixed-reader-23")

  extract <- `[`

  from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)

  accession_df_grp_1 <- reader_1(accession_df) |>
    merge_two_readers(ai_reader(accession_df), id = "reader-1-and-AI") |>
    reader_23(final_decision = TRUE) |>
    extract(from_reader_1, )

  accession_df_grp_2 <- reader_2(accession_df) |>
    merge_two_readers(ai_reader(accession_df), id = "reader-2-and-AI") |>
    reader_13(final_decision = TRUE) |>
    extract(!from_reader_1, )

  rbind(accession_df_grp_1, accession_df_grp_2)
}


#' AI replacement with mixed-simulated third reader
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_random_mixed_sim <- function(accession_df, reader_df, model_pred, threshold, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  ai_reader <- AI_reader(model_pred, threshold, "AI-reader")
  reader_3 <- mixed_reader(reader_df, 3, "mixed-reader-3", ...)

  from_reader_1 <- sample(c(T, F), nrow(accession_df), replace = TRUE)

  accession_df_grp_1 <- merge_two_readers(
    reader_1(accession_df),
    ai_reader(accession_df),
    id = "reader-1-and-AI"
  )[from_reader_1, ]

  accession_df_grp_2 <- merge_two_readers(
    reader_2(accession_df),
    ai_reader(accession_df),
    id = "reader-2-and-AI"
  )[!from_reader_1, ]

  rbind(accession_df_grp_1, accession_df_grp_2) |>
    reader_3(final_decision = TRUE)
}


# 2022-10-26 ===================================================================
#' Baseline scenario with simulated third reader
#'
#' @description This scenario verifies that the third reader is simulated in a
#' way that the consensus performance is close to the real data.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_pred A data frame; the data frame containing the model prediction.
#' @param threshold A scalar; the threshold for the model prediction.
#' @param ... Additional arguments to be passed to the simulated reader.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_baseline_check <- function(accession_df, reader_df, model_pred, threshold, ...) {
  message("Threshold is not used in this scenario.")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3", ...)

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)
}


# 2022-06-06 New scenario ======================================================
# Band-Pass independent = Band Pass + Reader 3
#' Band-pass screening with independent simulated third reader
#'
#' @description This scenario simulates the band-pass screening with one AI reader
#' at the front and one simulated reader (based on reader 3 performance) at the end.
#'
#' @param threshold A vector of length 2; the band-pass thresholds for the model prediction.
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_band_pass_independent <- function(accession_df, reader_df, model_pred, threshold) {
  stopifnot(length(threshold) == 2)

  low_band_reader <- AI_reader(model_pred, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_pred, threshold[2], "AI-reader")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  first_pass <- low_band_reader(accession_df)
  first_pass_recall <- first_pass |> filter(episode_prediction == 1)
  first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
  first_pass_no_recall$decided <- TRUE

  second_pass <- high_band_reader(first_pass_recall)
  second_pass_recall <- second_pass |> filter(episode_prediction == 1)
  second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
  second_pass_recall$decided <- TRUE

  third_read <- reader_3(second_pass_no_recall, final_decision = TRUE)
  rbind(first_pass_no_recall, second_pass_recall, third_read)
}


# Band-Pass screening = Band Pass + Reader 1,2 + Reader 3
#' Band-pass screening followed by standard pathway
#'
#' @param threshold A vector of length 2; the band-pass thresholds for the model prediction.
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_band_pass_screening <- function(accession_df, reader_df, model_pred, threshold) {
  stopifnot(length(threshold) == 2)

  low_band_reader <- AI_reader(model_pred, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_pred, threshold[2], "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  first_pass <- low_band_reader(accession_df)
  first_pass_recall <- first_pass |> filter(episode_prediction == 1)
  first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
  first_pass_no_recall$decided <- TRUE

  second_pass <- high_band_reader(first_pass_recall)
  second_pass_recall <- second_pass |> filter(episode_prediction == 1)
  second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
  second_pass_recall$decided <- TRUE

  pass_read <- reader_1(second_pass_no_recall) |>
    merge_two_readers(reader_2(second_pass_no_recall), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)

  rbind(first_pass_no_recall, second_pass_recall, pass_read)
}


# Band-pass screening manufacturer specific thresholds
#' Band-pass screening with manufacturer specific thresholds
#'
#' @description This scenario is the same as `AI_band_pass_screening` except that
#' the thresholds are different for each manufacturer.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_pred A data frame; the data frame containing the model prediction that
#' has been thresholded by the manufacturer specific thresholds.
#' @param model_pred_2 A data frame; the data frame containing the model prediction that
#' has been thresholded by the manufacturer specific thresholds.
#' @param threshold A vector of length 2; the band-pass thresholds for the model prediction.
#' In this case, the argument is only a dummy variable to be consistent with the other
#' scenarios. The thresholds are already applied to the model prediction.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_band_pass_screening_ms <- function(accession_df, reader_df, model_pred, model_pred_2, threshold) {
  stopifnot(length(threshold) == 2)

  low_band_reader <- AI_reader(model_pred, threshold[1], "AI-reader")
  high_band_reader <- AI_reader(model_pred_2, threshold[2], "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  first_pass <- low_band_reader(accession_df)
  first_pass_recall <- first_pass |> filter(episode_prediction == 1)
  first_pass_no_recall <- first_pass |> filter(episode_prediction == 0)
  first_pass_no_recall$decided <- TRUE

  second_pass <- high_band_reader(first_pass_recall)
  second_pass_recall <- second_pass |> filter(episode_prediction == 1)
  second_pass_no_recall <- second_pass |> filter(episode_prediction == 0)
  second_pass_recall$decided <- TRUE

  pass_read <- reader_1(second_pass_no_recall) |>
    merge_two_readers(reader_2(second_pass_no_recall), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)

  rbind(first_pass_no_recall, second_pass_recall, pass_read)
}


# AI replaces both reader 2 and 3
#' AI replacement of reader 2 and 3
#'
#' @description This scenario replaces the second and third reader with the AI reader.
#'
#' @param accession_df A data frame; the data frame containing the episodes to be read.
#' @param reader_df A data frame; the data frame containing the reader's read.
#' @param model_pred A data frame; the data frame containing the model prediction.
#' @param threshold A scalar; the threshold for the model prediction.
#' @param threshold_2 A scalar; the threshold for the model prediction.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_replacement_2_and_3 <- function(accession_df, reader_df, model_pred, threshold, threshold_2) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold, "AI-reader-2")
  reader_3 <- AI_reader(model_pred, threshold_2, "AI-reader-3")

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-AI") |>
    reader_3(final_decision = TRUE)
}


#===============================================================================
# Scenario 1a
#' AI autonomous screening (ideal)
#'
#' @description This scenario includes an AI reader at the beginning of the reading
#' pathway and then the three readers. The AI reader is allowed to make a final
#' decision.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_autonomous_screening_ideal <- function(accession_df, reader_df, model_pred, threshold = 0.05) {
  reader_0 <- AI_reader(model_pred, threshold, "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)
  accession_no_recall$decided <- TRUE

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2"),
    final_decision = TRUE
  )

  rbind(third_read, accession_no_recall)
}

# Scenario 1b
#' AI autonomous screening (practical)
#'
#' @description This scenario is the same as `AI_autonomous_screening_ideal` except that
#' the AI reader is not allowed to make a final decision. The no-recall episodes are
#' checked by a simulated fourth reader that is based on the performance of the first reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_autonomous_screening_practical <- function(accession_df, reader_df, model_pred, threshold = 0.05) {
  reader_0 <- AI_reader(model_pred, threshold, "AI-reader")
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")
  reader_4 <- simulated_reader(reader_df, 1, "reader-4")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2"),
    final_decision = TRUE
  )

  rbind(third_read, reader_4(accession_no_recall, final_decision = TRUE))
}

# Scenario 2a - replace reader 2
#' AI independent reading
#'
#' @description This scenario replaces the second reader with the AI reader.
#' The third reads are simulated based on the empirical performance of the third reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent <- function(accession_df, reader_df, model_pred, threshold = 0.05, ...) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold, "AI-reader-2")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3", ...)

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-AI") |>
    reader_3(final_decision = TRUE)
}

# Scenario 2b - replace reader 3
#' AI independent reading
#'
#' @description This scenario replaces the third reader with the AI reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_3 <- function(accession_df, reader_df, model_pred, threshold = 0.05) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- AI_reader(model_pred, threshold, "AI-reader-3")

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-1-and-2") |>
    reader_3(final_decision = TRUE)
}

# Scenario 2c - replace reader 1
#' AI independent reading
#'
#' @description This scenario replaces the first reader with the AI reader.
#' The third reads are simulated based on the empirical performance of the third reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_1 <- function(accession_df, reader_df, model_pred, threshold = 0.05, ...) {
  reader_1 <- AI_reader(model_pred, threshold, "AI-reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3", ...)

  reader_1(accession_df) |>
    merge_two_readers(reader_2(accession_df), id = "reader-2-and-AI") |>
    reader_3(final_decision = TRUE)
}

# Scenario 2d - randomly replace reader 1 or 2
#' AI independent reading
#'
#' @description This scenario replaces the first or second reader (randomly with 50/50 probabilities)
#' with the AI reader. The third reads are simulated based on the empirical performance of the third reader.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_independent_replace_random <- function(accession_df, reader_df, model_pred, threshold = 0.05, ...) {
  result_1 <- AI_independent_replace_1(accession_df, reader_df, model_pred, threshold, ...)
  result_2 <- AI_independent(accession_df, reader_df, model_pred, threshold, ...)
  from_reader_1 <- sample(c(T, F), nrow(result_1), replace = TRUE)
  stopifnot(all(result_1$episode_id == result_2$episode_id))
  rbind(
    result_1[which(from_reader_1), ],
    result_2[which(!from_reader_1), ]
  ) |>
    arrange(episode_id)
}

# Scenario 5
#' AI final-pass reading
#'
#' @description This scenario adds an AI reader at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
AI_final_pass <- function(accession_df, reader_df, model_pred, threshold = 0.8) {
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")
  reader_4 <- AI_reader(model_pred, threshold, "AI-reader")

  first_read <- reader_1(accession_df)
  second_read <- reader_2(accession_df)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2")
  )

  accession_recall <- third_read |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- third_read |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))
  attr(res, "extra") <- list(
    n_reader_3 = third_read |> filter(by == "reader-3") |> nrow()
  )
  res
}

# Scenario 6 - AI autonomous screening (ideal) + AI independent ----------------
#' AI autonomous screening (ideal) + AI independent
#'
#' @description This scenario adds an AI reader at the beginning of the standard pathway,
#' and replaces the second reader with the AI reader.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of two numbers, the first is the threshold for the AI
#' autonomous screening, and the second is the threshold for the AI independent reading.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_independent <- function(accession_df, reader_df, model_pred, threshold = c(0.05, 0.05)) {
  stopifnot(length(threshold) == 2)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")

  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold[2], "AI-reader-independent")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)
  accession_no_recall$decided <- TRUE

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2"),
    final_decision = TRUE
  )

  rbind(third_read, accession_no_recall)
}


# Scenario 7 - AI autonomous screening (ideal) + final pass --------------------
#' AI autonomous screening (ideal) + final pass
#'
#' @description This scenario adds an AI reader at the beginning of the standard pathway,
#' and adds an AI reader at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of two numbers, the first is the threshold for the AI
#' autonomous screening, and the second is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_final_pass <- function(accession_df, reader_df, model_pred, threshold = c(0.05, 0.8)) {
  stopifnot(length(threshold) == 2)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")

  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- admani_reader(reader_df, 2, "reader-2")
  reader_3 <- admani_reader(reader_df, 3, "reader-3")

  reader_4 <- AI_reader(model_pred, threshold[2], "AI-reader-final-pass")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-2")
  )

  autonomous <- rbind(third_read, accession_no_recall)
  accession_recall <- autonomous |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- autonomous |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))

  # Add extra information from the intermediate stages that cannot be recovered
  # at the end of the simulation.
  attr(res, "extra") <- list(
    screening_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 1) |>
      nrow(),
    screening_no_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 0) |>
      nrow(),
    n_reader_3 = third_read |> filter(by == "reader-3") |> nrow()
  )
  res
}


# Scenario 8 - AI independent reader 2 + final pass ----------------------------
#' AI independent reader 2 + final pass
#'
#' @description This scenario replaces the second reader with an AI reader, and adds
#' an AI reader at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of two numbers, the first is the threshold for the AI
#' independent reading, and the second is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
independent_final_pass <- function(accession_df, reader_df, model_pred, threshold = c(0.05, 0.8)) {
  stopifnot(length(threshold) == 2)
  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold[1], "AI-reader-independent")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  reader_4 <- AI_reader(model_pred, threshold[2], "AI-reader-final-pass")

  first_read <- reader_1(accession_df)
  second_read <- reader_2(accession_df)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-AI"),
    final_decision = FALSE
  )

  accession_recall <- third_read |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- third_read |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))
  attr(res, "extra") <- list(
    n_reader_3 = third_read |> filter(by == "sim-reader-3") |> nrow()
  )
  res
}


# Scenario 9 - AI autonomous screening (ideal) + AI independent + final pass ----
#' AI autonomous screening (ideal) + AI independent + final pass
#'
#' @description This scenario adds an AI reader at the beginning of the standard pathway,
#' replaces the second reader with an AI reader, and adds an AI reader at the end of
#' the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of three numbers, the first is the threshold for the AI
#' autonomous screening, the second is the threshold for the AI independent reading,
#' and the third is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_independent_final_pass <- function(accession_df, reader_df, model_pred,
                                              threshold = c(0.05, 0.05, 0.8)) {
  stopifnot(length(threshold) == 3)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")

  reader_1 <- admani_reader(reader_df, 1, "reader-1")
  reader_2 <- AI_reader(model_pred, threshold[2], "AI-reader-independent")
  reader_3 <- simulated_reader(reader_df, 3, "sim-reader-3")

  reader_4 <- AI_reader(model_pred, threshold[3], "AI-reader-final-pass")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  first_read <- reader_1(accession_recall)
  second_read <- reader_2(accession_recall)
  third_read <- reader_3(
    merge_two_readers(first_read, second_read, id = "reader-1-and-AI")
  )

  autonomous <- rbind(third_read, accession_no_recall)
  accession_recall <- autonomous |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- autonomous |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall, reader_4(accession_no_recall, final_decision = TRUE))

  # Add extra information from the intermediate stages that cannot be recovered
  # at the end of the simulation.
  attr(res, "extra") <- list(
    screening_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 1) |>
      nrow(),
    screening_no_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 0) |>
      nrow(),
    n_reader_3 = third_read |> filter(by == "sim-reader-3") |> nrow()
  )
  res
}


# Scenario 9b - AI autonomous screening (ideal) + single AI independent + final pass ----
#' AI autonomous screening (ideal) + single AI independent + final pass
#'
#' @description This scenario replaces the standard pathway with a single AI reader, and
#' adds an AI reader at the beginning and at the end of the standard pathway.
#'
#' @inheritParams AI_baseline_check
#' @param threshold A vector of three numbers, the first is the threshold for the AI
#' autonomous screening, the second is the threshold for the AI independent reading,
#' and the third is the threshold for the AI final pass.
#'
#' @return A data frame; the result of the scenario simulation.
#' @export
autonomous_single_independent_final_pass <- function(accession_df, reader_df, model_pred,
                                                     threshold = c(0.05, 0.05, 0.8)) {
  stopifnot(length(threshold) == 3)
  reader_0 <- AI_reader(model_pred, threshold[1], "AI-reader-screening")
  reader_2 <- AI_reader(model_pred, threshold[2], "AI-reader-independent")
  reader_4 <- AI_reader(model_pred, threshold[3], "AI-reader-final-pass")

  screened_accession <- reader_0(accession_df)
  accession_recall <- screened_accession |> filter(episode_prediction == 1)
  accession_no_recall <- screened_accession |> filter(episode_prediction == 0)

  middle_read <- reader_2(accession_recall)

  autonomous <- rbind(middle_read, accession_no_recall)
  accession_recall <- autonomous |> filter(episode_prediction == 1)
  accession_recall$decided <- TRUE
  accession_no_recall <- autonomous |> filter(episode_prediction == 0)
  accession_no_recall$decided <- FALSE

  res <- rbind(accession_recall,
               reader_4(accession_no_recall, final_decision = TRUE))

  # Add extra information from the intermediate stages that cannot be recovered
  # at the end of the simulation.
  attr(res, "extra") <- list(
    screening_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 1) |>
      nrow(),
    screening_no_recall = screened_accession |>
      filter(by == "AI-reader-screening", episode_prediction == 0) |>
      nrow(),
    n_reader = middle_read |> filter(by == "AI-reader-independent") |> nrow()
  )
  res
}
